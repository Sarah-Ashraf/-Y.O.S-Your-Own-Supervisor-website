CREATE DEFINER=`root`@`localhost` PROCEDURE `gpa_sem`(IN st_ssn INT)
BEGIN
declare gpa_sem double;

select sum(hours) into @totalH
from reg , student
where student_ssn = ssn and student_ssn = st_ssn
group by  level, semester;

select sum(hours*points) into @Hpoints
from reg , student
where student_ssn = ssn and student_ssn = st_ssn
group by level, semester;

set gpa_sem = @Hpoints/@totalH;

select gpa_sem;
END