CREATE DEFINER=`root`@`localhost` PROCEDURE `total_gpa`(in st_ssn int)
BEGIN
select sum(hours) into @totalH
from reg 
where student_ssn = st_ssn;

select sum(points*hours) into @ptH
from reg 
where student_ssn = st_ssn;

select @ptH/@totalH;
END