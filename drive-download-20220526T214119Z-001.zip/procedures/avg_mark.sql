select course_code as "course code", name , avg(mark) as Average , year , count(student_ssn) as "number of students"
from reg , course
where reg.course_code = course.code and reg.course_type = course_type
group by (course_code)
