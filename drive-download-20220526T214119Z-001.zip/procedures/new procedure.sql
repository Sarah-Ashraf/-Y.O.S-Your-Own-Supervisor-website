CREATE DEFINER=`root`@`localhost` PROCEDURE `new_procedure`(IN st_ssn INT)
BEGIN


select student.level into @lvl
from student 
where ssn =st_ssn;

select program_number into @pno
from student
where ssn = st_ssn;

if @lvl = 4 then 
select code ,name , credithour, type
from course , include
where course.code = include.course_code and course.type = include.course_type and 
code not in (
select course_code 
from reg 
where student_ssn = st_ssn and Grade != 'F') and program_number = @pno and include.level <= @lvl and activated = true ;

elseif @lvl >= 1 and @lvl <=3 then
select code ,name , credithour, type
from course , include
where course.code = include.course_code and course.type = include.course_type and 
code not in (
select course_code 
from reg 
where student_ssn = st_ssn and Grade != 'F') and program_number = @pno and include.level <= @lvl+1 and activated = true;
END IF;
END