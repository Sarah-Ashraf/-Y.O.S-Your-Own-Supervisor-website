CREATE DEFINER=`root`@`localhost` PROCEDURE `allowed_hours`(IN st_ssn INT )
BEGIN

declare allowed_hours varchar(45) ;
declare sem_no varchar(45);

select monthname(current_date()) into @m;
if(@m ='September' or @m= 'October' or @m= 'November') then
set sem_no = 1;
elseif(@m ='February' or @m= 'March'or @m = 'May') then
set sem_no = 2;
elseif(@m ='July' or @m='August') then
set sem_no = 2;
end if;

select gpa into @gpa 
from student
where ssn = st_ssn;

SELECT level INTO @lvl 
FROM student
WHERE ssn = st_ssn;

SELECT program_number INTO @pno 
FROM student
WHERE ssn = st_ssn;


if (@gpa >=2 and @gpa <=4 ) or @lvl = 1 then 
	set allowed_hours = (select hours 
        from prog_plans
        where program_number = @pno and level = @lvl and semester = sem_no );
        
	elseif (@gpa < 2 and @gpa > 0) and @lvl >=2 and @lvl <= 4 then
		set allowed_hours = 12;
END IF;

select allowed_hours;

END