<?php
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

if (mysqli_connect_errno()) {
    die("cannot connect to database failed:" . mysqli_connect_errno());
}

if (isset($_POST['add'])) {
    $sup_name = $_POST['supername'];
    $sup_ssn = $_POST['superssn'];
    $sup_email = $_POST['superemail'];
    $sup_user = $_POST['superusername'];
    $sup_pass = $_POST['superpassword'];

    $sql = "INSERT INTO supervisor (supssn,supemail,supusername,suppassword,supname)
        VALUES ('$sup_ssn','$sup_email','$sup_user','$sup_pass','$sup_name')";

    $result1 = mysqli_query($data, $sql);

    if ((empty($sup_name)) || (empty($sup_email)) || (empty($sup_pass)) || (empty($sup_ssn)) || (empty($sup_user))) 
    {
        echo ' <script type="text/javascript">alert(" enter all data")</script>';
    }
    else
    {
        if ($result1) {
            echo ' <script type="text/javascript">alert(" Record inserted successfully")</script>';
        } else {
            echo '<script type="text/javascript">alert(" Record inserted failed")</script>';
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Y.O.S</title>

    <style type="text/css">
        label {
            display: inline-block;
            text-align: left;
            width: 100px;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .div_deg {
            background-color: skyblue;
            width: 400px;
            padding-top: 40px;
            padding-bottom: 40px
        }
    </style>

    <?php
    include 'admin_css.php';
    ?>

</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>
    <div class="content">
        <center>
            <h1 class="adm">Add New Supervisor</h1>
        </center>
        <div align="center" class="add">
            <form class="form_deg" action="#" method="POST">

                <div class="add_int">
                    <label class="label_text">Name</label>
                    <input class="input_deg" type="text" name="supername" value="" />
                </div>

                <div class="add_int">
                    <label class="label_text">National ID</label>
                    <input class="input_deg" type="number" name="superssn" value="" />
                </div>

                <div class="add_int">
                    <label class="label_text">Username</label>
                    <input class="input_deg" type="text" name="superusername" value="" />
                </div>

                <div class="add_int">
                    <label class="label_text">Password</label>
                    <input class="input_deg" type="text" name="superpassword" onChange={handelInput} value="" />
                </div>

                <div class="add_int">
                    <label class="label_text">Email</label>
                    <input class="input_deg" type="email" name="superemail" onChange={handelInput} />
                </div>



                <div class="add_int">
                    <button class="btn btn-primary" id="submit" type="submit" name="add"> Add Supervisor </button>
                </div>

            </form>
        </div>
    </div>
</body>

</html>