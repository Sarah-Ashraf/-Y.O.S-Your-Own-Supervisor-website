<?php
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);
$supervisor_ssn = $_GET['supervisor_assn'];

$sql = "SELECT * FROM supervisor WHERE supssn=$supervisor_ssn";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();


if (isset($_POST['uppdate_supervisor'])) {
    $sup_email=$_POST['email'];
    $sup_pass=$_POST['password'];
    $supssn=$_POST['supssn'];
    $sql2 = " UPDATE supervisor SET supemail='$sup_email' , suppassword='$sup_pass' where supssn=' $supssn' ";
    $result2 = mysqli_query($data, $sql2);
    
    if ( (empty($sup_email)) || (empty($sup_pass)) ) 
    {
        echo ' <script type="text/javascript">alert(" enter updated data ,please")</script>';
    }
    else{
        if ($result2) {
            echo' <script type="text/javascript">alert(" updated successfully") </script>';
            }
        else {
            echo' <script type="text/javascript">alert(" updated failed") </script>';  
            }
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title> Y.O.S </title>

    <?php
            include 'admin_css.php';
        ?>


    <style type="text/css">
    label {
        display: inline-block;
        text-align: left;
        width: 100px;
        padding-top: 10px;
        padding-bottom: 10px;
    }

    .form_deg {
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>


</head>

<body>

    <?php
        include 'admin_sidebar.php';
        ?>

    <div class="content">
        <center>
            <h1>Update Supervisor</h1>

            <form class="form_deg" action="#" method="POST">
                <input type="text" name="supssn" value="<?php echo "{$info['supssn']}" ?>" hidden />

                <div class="add_int">
                    <label class="label_text">Name</label>
                    <input class="input_deg" type="text" name="supname" value="<?php echo "{$info['supname']}"; ?>" readonly />
                </div>

                <div class="add_int">
                    <label class="label_text">National ID</label>
                    <input class="input_deg" type="number" name="supssn" value="<?php echo "{$info['supssn']}"; ?>" readonly />
                </div>

                <div class="add_int">
                    <label class="label_text">Username</label>
                    <input class="input_deg" type="text" name="supusername" value="<?php echo "{$info['supusername']}"; ?>" readonly />
                </div>

                <div class="add_int">
                    <label class="label_text">Password</label>
                    <input class="input_deg" type="text" name="password" placeholder="Enter new password" />
                </div>

                <div class="add_int">
                    <label class="label_text">Email</label>
                    <input class="input_deg" type="email" name="email" value="<?php echo "{$info['supemail']}"; ?>"/>
                </div>

                <div class="add_int">
                    <button class="btn btn-success" id="submit" type="submit" name="uppdate_supervisor">Update</button>
                </div>

            </form>
    </center>
    </div>
</body>

</html>
