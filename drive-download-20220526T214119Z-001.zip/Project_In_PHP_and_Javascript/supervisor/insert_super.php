<?php

session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$user_ssn = $_GET['Supervisor_ssn'];

$sql = "SELECT * FROM user WHERE assn='$user_ssn'";

$result = mysqli_query($data, $sql);

$info = $result->fetch_assoc();

if (isset($_POST['insert_super'])) {
    $username = $_POST['username'];
    $user_name = $_POST['aname'];
    $user_ssn = $_POST['assn'];
    $user_pass = $_POST['user_password'];

    $query = "UPDATE user SET username='$username',aname='$user_name',assn='$user_ssn',user_password='$user_pass' WHERE assn='$user_ssn'";

    $result1 = mysqli_query($data, $query);

    if ($result1) {
        //header("location:view_student.php");
        $sup_name=$_POST['supname'];
        $sup_ssn=$_POST['supssn'];
        $sup_email=$_POST['supemail'];
        $sup_user=$_POST['supusername'];
        $sup_pass=$_POST['suppassword'];

        $sql2 = "INSERT INTO supervisor (supssn,supemail,supusername,suppassword,supname)
        VALUES ('$sup_ssn','$sup_email','$sup_user','$sup_pass','$sup_name')";

        $result2 = mysqli_query($data, $sql2);
        if ($result2) {
            echo "<script type='text/javascript'>
                alert('Data Updated Successfully');
                </script>";
        } else {
            echo "Faild Insertion";
        }
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title> Y.O.S </title>

    <style type="text/css">
    label {
        display: inline-block;
        text-align: left;
        width: 100px;
        padding-top: 10px;
        padding-bottom: 10px;
    }

    .div_deg {
        background-color: skyblue;
        width: 400px;
        padding-top: 40px;
        padding-bottom: 40px
    }
    </style>

    <?php
            include 'admin_css.php';
        ?>

</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>


    <center>
        <h1 class="adm">Insert Supervisor</h1>
    </center>
    <div align="center" class="add">
    <form class="form_deg" action="#" method="POST">
                <input type="text" name="supssn" value="<?php echo "{$info['supssn']}" ?>" hidden />
            <div class="add_int">
                <label class="label_text">Name</label>
                <input class="input_deg" type="text" name="supname" value="<?php echo "{$info['supssn']}" ?>" />
            </div>

            <div class="add_int">
                <label class="label_text">National ID</label>
                <input class="input_deg" type="number" name="supssn" value="<?php echo "{$info['supssn']}" ?>" />
            </div>

            <div class="add_int">
                <label class="label_text">User Name</label>
                <input class="input_deg" type="text" name="supusername" value="<?php echo "{$info['supssn']}" ?>"/>
            </div>

            <div class="add_int">
                <label class="label_text">Password</label>
                <input class="input_deg" type="text" name="suppassword" onChange={handelInput} value="<?php echo "{$info['supssn']}" ?>" />
            </div>
            
            <div class="add_int">
                <label class="label_text">Email</label>
                <input class="input_deg" type="email" name="supemail" onChange={handelInput} />
            </div>

            
            <div class="add_int">
                <button class="btn btn-primary" id="submit" type="submit" name="insert_super"> Insert Supervisor </button>
            </div>

        </form>
    </div>

</body>

</html>