<?php

    session_start();

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "yos";

    $data= mysqli_connect($dbhost,$dbuser,$dbpass,$db);

    if(mysqli_connect_errno())
    {
        die("cannot connect to database faile:".mysqli_connect_errno());
    }

    else
    {
        echo"database is connected";
    }

    if(isset($_POST['add']))
    {
        $sup_name=$_POST['supname'];
        $sup_ssn=$_POST['supssn'];
        $sup_email=$_POST['supemail'];
        $sup_user=$_POST['supusername'];
        $sup_pass=$_POST['suppassword'];
    
        $sql="INSERT INTO supervisor (supssn,supemail,supusername,suppassword,supname)
        VALUES ('$sup_ssn','$sup_email','$sup_user','$sup_pass','$sup_name')";

        $result1 = mysqli_query($data, $sql);


        if ($result1) {

            echo "Your Form was Successfully Insert";
        }

        else
        {
            echo "Ther was an error in Inserting your Form";
        }

        if((empty($sup_name))||(empty($sup_email))||(empty($sup_pass))||(empty($sup_ssn))||(empty($sup_user)))
        {
            echo"enter whole data";

        }
        else
        {
            $result=mysqli_query($data, $sql);
            echo' <script type="text/javascript">alert(" Record inserted successfully")</script>';
        }

    }

?>