<?php
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$user_ssn = $_GET['supervisor_assn'];

$sql = "SELECT * FROM supervisor WHERE supssn='$user_ssn'";

$result = mysqli_query($data, $sql);

$info = $result->fetch_assoc();

if (isset($_POST['add_course'])) {
    $code = $_POST['course_code'];
    $semester = $_POST['semester'];
    $year = $_POST['year'];
    $super_ssn = $_POST['supervisor_supssn'];

    if (!empty($_POST['course_code']) && !empty($_POST['semester']) && !empty($_POST['year']) && !empty($_POST['supervisor_supssn'])) {
        $sql2 = "INSERT INTO partic(supervisor_supssn,year,semester,course_code)VALUES('$super_ssn','$year','$semester','$code')";
        $result2 = mysqli_query($data, $sql2);
        if ($result2) {
            echo "<script type='text/javascript'>
                    alert('Data Inserted Successfully');
                    </script>";
        } else {
            echo "Faild Insertion";
        }
    } else {
        echo " Please enter all fields";
    }


    //}
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title> Y.O.S </title>

    <?php
    include 'admin_css.php';
    ?>


    <style type="text/css">
        label {
            display: inline-block;
            text-align: left;
            width: 100px;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .form_deg {
            padding-top: 40px;
            padding-bottom: 40px;
        }
    </style>


</head>

<body>

    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <h1>Add Course</h1>

            <form class="form_deg" action="#" method="POST">
                <input type="text" name="supssn" value="<?php echo "{$info['supssn']}" ?>" hidden />

                <div class="add_int">
                    <label class="label_text">Name</label>
                    <input class="input_deg" type="text" name="supervisor_supssn" value="<?php echo "{$info['supname']}" ?>" readonly />
                </div>

                <div class="add_int">
                    <label class="label_text">National ID</label>
                    <input class="input_deg" type="number" name="supervisor_supssn" value="<?php echo "{$info['supssn']}" ?>" readonly/>
                </div>

                <div class="wrapper">
                    <div class="search-input">
                        <label class="label_text">Course Code</label>
                        <input class="input_deg" type="text" placeholder="enter course code.." name="course_code" />
                        <div class="autocom-box">
                            <!-- here list are inserted from javascript -->
                        </div>
                    </div>
                </div>

                <script src="suggestions.js"></script>
                <script src="script.js"></script>

                <div class="add_int">
                    <label class="label_text">Semester</label>
                    <select name="semester">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                    </select>

                </div>

                <div class="add_int">
                    <label class="label_text">Level</label>
                    <select name="year">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                </div>

                <div class="add_int">
                    <button class="btn btn-success" id="submit" type="submit" name="add_course">Add</button>
                </div>

            </form>
    </div>
    </center>

</body>

</html>