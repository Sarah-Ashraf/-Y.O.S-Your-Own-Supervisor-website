<header class="header">
<nav>
        <img class="nav_img1" src="UNlogo.png">
        <a href="" class="aa">Admin Dashboard</a>
        <div class="logout">
            <a href="logout.php" class="btn btn-primary">Log Out</a>
            <img class="nav_img2" src="Flogo.png">
        </div>
    </nav>

</header>
<aside>
    <ul>
        <!--<li>
            <div class="dropdown">
                <a class="dropbtn">Admin</a>
                <div class="dropdown-content">
                    <a href="">Add New Admin</a>
                    <a href="">View Admins</a>
                </div>
            </div>
        </li>-->
        
        <li>
            <div class="dropdown">
                <a class="dropbtn">Students</a>
                <div class="dropdown-content">
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/add_student.php">Add New Student</a>
                    <!--<a href="view_student_user.php">View Students (User)</a>-->
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/view_students.php">View Students</a>
                </div>
            </div>
        </li>
        <br><br><br>
        <li>
            <div class="dropdown">
                <a class="dropbtn">Supervisor</a>
                <div class="dropdown-content">
                    <a href="/Project_In_PHP_and_Javascript/supervisor/add_super.php">Add New Supervisor</a>
                    <a href="/Project_In_PHP_and_Javascript/supervisor/view_super.php">View Supervisors</a>
                </div>
            </div>
        </li>
        <br><br><br>
        <li><a href="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/actcour.php">Summer</a></li>
        <br><br><br>
        <li><a href="/Project_IN_PHP_AND_JAVASCRIPT/active_donia/activateCourses.php">Courses Activate</a></li>


    </ul>
</aside>