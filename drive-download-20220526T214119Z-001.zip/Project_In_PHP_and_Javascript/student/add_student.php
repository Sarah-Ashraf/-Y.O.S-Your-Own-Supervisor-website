<?php
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

//$student_sssn = $_GET['ssn'];

//$sql = "SELECT * FROM student ";

//$result = mysqli_query($data, $sql);

//$info = $result->fetch_assoc();

if (isset($_POST['insert'])) {
    $student_ssn = $_POST['ssn'];
    $student_phone = $_POST['phone'];
    $student_name = $_POST['stname'];
    $student_username = $_POST['stusername'];
    $student_pass = $_POST['stpassword'];
    $student_nationality = $_POST['nationality'];
    $student_level = $_POST['level'];
    //$student_gpa = $_POST['gpa'];
    $student_academic_number = $_POST['acadamiccode'];
    $student_program_number = $_POST['program_number'];
    $student_super_ssn = $_POST['supervisor_supssn'];

    $sql2 = "INSERT INTO student(ssn,phone,stname,stusername,stpassword,nationality,level,acadamiccode,program_number,supervisor_supssn)
    VALUES('$student_ssn','$student_phone','$student_name','$student_username','$student_pass','$student_nationality'
    ,'$student_level','$student_academic_number','$student_program_number','$student_super_ssn')";
    $result = mysqli_query($data, $sql2);

    if (empty($_POST['stusername']) && empty($_POST['stname']) && empty($_POST['ssn']) && empty($_POST['stpassword']) && empty($_POST['phone']) && empty($_POST['nationality']) && empty($_POST['level']) && empty($_POST['acadamiccode']) && empty($_POST['program_number']) && empty($_POST['supervisor_supssn'])) {
        //echo " Please enter all fields";
        echo '<div style ="background-color:rgb(250, 0, 70); color:white; font-size: 27px;" class="alert alert-danger" role="alert">';
        echo 'Please enter all fields';
        echo '</div>';
    } else {
        if ($result) {
            //echo "<script type='text/javascript'> alert('Data Inserted Successfully');</script>";
            echo '<div style="background-color:rgb(54, 201, 123); color:white; margin-right:50px; font-size: 27px;" class="alert alert-success" role="alert">';
            echo 'Data Inserted Successfully!';
            echo '</div>';
        } else {
            //echo "Faild Insertion";
            echo '<div style="background-color:rgb(54, 201, 123); color:white; margin-right:50px; font-size: 27px;" class="alert alert-success" role="alert">';
            echo 'Faild Insertion';
            echo '</div>';
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Y.O.S</title>
    <?php
    include 'admin_css.php';
    ?>
    <style type="text/css">
        label {
            display: inline-block;
            text-align: left;
            width: 150px;
            padding-top: 10px;
            padding-bottom: 10px;
            padding-left: 10px;
            /*margin-right: 10px;*/
        }


        .div_deg {
            background-color: skyblue;
            /*width: 400px;*/
            padding-top: 50px;
            padding-bottom: 40px;
            border-style: solid;
            border-color: black;
            width: 65%;
            /*border-radius: 25px 25px 25px 25px;*/
        }

        .form_deg {
            padding-top: 100px;
            width: 450px;
            padding-right: 30px;
            margin-left: 60px;

            /*background: linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%);*/
            border-radius: 25px 25px 25px 25px;
            padding-top: 1px;
            /*padding-bottom: 10px;*/
            margin-bottom: 10px;
        }
    </style>


</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <h1 style="font-size: 37px;">Add New Student</h1>
            <br>
            <table class="div_deg" border="2">
                <div>
                    <form action="#" method="POST" class="form_deg">
                        <tr>
                            <td> <label class="label" style="width:10px;">Acd.No.</label></td>
                            <td><input placeholder="Enter academic number" class="input" type="number" name="acadamiccode"></td>
                            <div>
                                <td><label style="padding-right: 140px;">Username</label></td>
                                <td><input placeholder="Enter username" class="input" type="text" name="stusername"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td> <label style="padding-right: 140px;">Name</label></td>
                                <td><input placeholder="Enter name" class="input" type="text" name="stname"></td>
                            </div>

                            <div>
                                <td><label style="padding-right: 140px;">SSN</label></td>
                                <td><input placeholder="Enter ssn" class="input" type="number" name="ssn"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label style="padding-right: 140px;">Password</label></td>
                                <td><input placeholder="Enter password" class="input" type="text" name="stpassword"></td>
                            </div>

                            <div>
                                <td><label style="padding-right: 140px;">Phone</label></td>
                                <td><input placeholder="Enter phone" class="input" type="number" name="phone"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label style="padding-right: 140px;">Nationality</label></td>
                                <td><input placeholder="Enter nationality" class="input" type="text" name="nationality"></td>
                            </div>

                            <div>
                                <td><label style="padding-right: 140px;">Level</label></td>
                                <td><input placeholder="Enter level" class="input" type="number" name="level"></td>
                            </div>
                        </tr>

                        <tr>


                            <div>
                                <td><label class="label">Program Number</label></td>
                                <td><input placeholder="Enter progrm number" class="input" type="number" name="program_number"></td>
                            </div>

                            <div>
                                <td><label class="label">Supervisor SSN</label></td>
                                <td><input placeholder="Enter supervisor snn" class="input" type="number" name="supervisor_supssn"></td>
                            </div>
                        </tr>


                        <tr>

                            <td></td>
                            <td colspan="3"> <input type="submit" style="margin-left: 130px; margin-bottom: 9px; margin-top: 8px;" class="btn btn-success" name="insert" value="Add Student"></td>

                        </tr>
                    </form>
                </div>
            </table>
        </center>
    </div>
</body>

</html>