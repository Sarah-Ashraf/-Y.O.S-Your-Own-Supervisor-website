<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="student.css" />
    <title>Y.O.S</title>
</head>

<body>
    <nav>
        <div class="logo">
            <img src="UNlogo.png"/>
            <h4>Y.O.S</h4>
        </div>
        <ul class="nav-item">
            <li class="nav-item">
                <a href="index.html" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <button class="dropbtn">MY</button>
                    <div class="dropdown-content">
                      <a href="#">INFO</a>
                      <a href="#">Academic Points</a>
                      <a href="#">Electronic Operation</a>
                    </div>
                  </div>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <button class="dropbtn">Academic Degrees</button>
                    <div class="dropdown-content">
                      <a href="gpa_2018.html">2018 - 2019</a>
                      <a href="gpa_2019.html">2019 -2020</a>
                      <a href="gpa_2020.html">2020 - 2021</a>
                    </div>
                  </div>
            </li>
           
            <li class="nav-item">
                <a href="#" class="nav-link">About Academic Guideness</a>
            </li>
            <li>
                <button class="btn3" ><a href="logout.php">Log Out</a></button>
            </li>
        </ul>
        <div class="logo">
            <img src="Flogo.png"/>
        </div>
    </nav>
    
</body>
<section class="student">
    <div class="student-section">
        <div class="content">
            <table style="width: 100%">
                <tr>
                    <th>Name :</th>
                    <td>Sarah Ashraf</td>
                </tr>
                <tr>
                    <th>Department :</th>
                    <td>Computer Science</td>

                    <td class="td1"><button class="btn2"><a href="studentSubject.html">7 Subject <br> <br>Spring Semster</a></button></td>
                </tr>
                <tr>
                    <th>Level :</th>
                    <td>Level 4</td>
                    
                </tr>
                <tr>
                    <th>Academic Number :</th>
                    <td>130000</td>
                    <td class="td1"><button class="btn2"><a href="#">Academic Supervisor Email: <br><br>Dr.Mohamid@gmail.com</a></button></td>
                </tr>
            </table>
            
        </div>
    
</section>

</html>