<?php

error_reporting(0);
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM student,supervisor WHERE student.supervisor_supssn=supervisor.supssn ";

$result = mysqli_query($data, $sql);

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Student</title>
    <?php
    include 'admin_css.php';
    ?>
    <style type="text/css">
        .table_th {
            width: 10%;
            /*font-size: 20px;*/
            text-align: center;
            color: black;
            background-color: skyblue;
            font-size: 15px;

        }

        .table_td {
            padding: 9px;
            background-color: white;
            /*padding-left: 15px;*/
            font-size: 15px;
            /*text-align: left;*/
            /*padding-right: 20px;*/
            /*width: 15px;*/
            /*width: fit-content;*/
        }

        table,
        th,
        td {
            border: 1px solid black;
            width: fit-content;

            /*font-size: 15px;*/
            margin-left: -2%;
            margin-right: 2%;
            text-align: center;
        }
    </style>


</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <?php
            if ($_SESSION['message']) {
                //echo $_SESSION['message'];
                echo '<div style="background-color:rgb(54, 201, 123); color:white; margin-right:50px; font-size: 30px;" class="alert alert-success" role="alert">';
                echo $_SESSION['message'];
                echo '</div>';
            }
            //echo '<div type="" class="alert alert-danger" role="alert">';
            unset($_SESSION['message']);
            //echo '</div>';
            ?>
            <h1 style="font-size: 37px;">Student's Data</h1>

            <br>
            <table>
                <tr>
                    <th class="table_th">Acd.No.</th>
                    <th class="table_th">Name</th>
                    <th class="table_th">Username</th>
                    <th class="table_th">SSN</th>
                    <th class="table_th">Phone</th>
                    <th class="table_th" style="padding: 5px;">Password</th>
                    <th class="table_th" style="padding: 5px;">Level</th>
                    <th class="table_th" style="padding: 5px;">Program</th>
                    <!--<th class="table_th">Course Code</th>-->
                    <th class="table_th" style="padding: 5px;">Supervisor Name</th>
                    <th class="table_th" style="padding: 5px;">GPA</th>
                    <th class="table_th">Courses & Degrees</th>
                    <th class="table_th">Delete</th>
                    <th class="table_th">Update</th>



                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['acadamiccode']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['stname']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['stusername']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['ssn']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['phone']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['stpassword']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['level']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php
                            if ("{$info['program_number']}" == '1') {
                                echo "CS";
                            } else if ("{$info['program_number']}" == '2') {
                                echo "SS";
                            } else if ("{$info['program_number']}" == '3') {
                                echo "GS";
                            }
                            ?>
                        </td>

                        <!--<td class="table_td">
                            <?php //echo "{$info['course_code']}"; 
                            ?>
                        </td>-->

                        <td class="table_td">
                            <?php if ($info['supervisor_supssn']) {
                                echo $info['supname'];
                            } ?>
                        </td>

                        <td class="table_td">
                            <?php echo "{$info['gpa']}"; //echo "<a class='btn btn-success' href='insert_GPA.php?student_ssn={$info['ssn']}'> Add GPA </a>"; 
                            ?>
                        </td>

                        <td class="table_td" style="padding-left: 5px;">
                            <?php echo "<a class='btn btn-success' style='font-size:12px;' href='insert_GPA.php?ssn={$info['ssn']}'> Courses & Degrees </a>"; ?>
                        </td>

                        <td class="table_td" style="padding-left: 5px; padding: 5px;">
                            <?php echo "<a class='btn btn-danger' style='font-size:12px;' onClick=\"javascript:return confirm('Are You Sure To Delete This');\" href='delete.php?ssn={$info['ssn']}'> Delete Student </a>"; ?>
                        </td>

                        <td class="table_td" style="padding-left: 5px; padding: 5px;">
                            <?php echo "<a class='btn btn-primary' style='font-size:12px;' href='update_student.php?ssn={$info['ssn']}'> Update Data </a>"; ?>
                        </td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>