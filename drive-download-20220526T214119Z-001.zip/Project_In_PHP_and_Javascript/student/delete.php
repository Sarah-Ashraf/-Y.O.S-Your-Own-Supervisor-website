<?php


session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

if ($_GET['ssn']) {
    $student_ssn = $_GET['ssn'];
    $sql2 = "DELETE FROM student WHERE ssn='$student_ssn'";
    $result = mysqli_query($data, $sql2);
    if ($result) {
        $_SESSION['message'] = 'Student is Deleted Successfully';
        header("location:/Project_IN_PHP_AND_JAVASCRIPT/student/view_students.php");
    } 
}
