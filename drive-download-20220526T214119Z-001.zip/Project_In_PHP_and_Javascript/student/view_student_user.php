<?php

error_reporting(0);
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM student WHERE usertype='student'";

$result = mysqli_query($data, $sql);

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Student</title>
    <?php
    include 'admin_css.php';
    ?>
    <style type="text/css">
        .table_th {
            padding: 20px;
            font-size: 20px;
        }

        .table_td {
            padding: 20px;
            background-color: white;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }
    </style>


</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <h1>(Users)Student Data</h1>
            <br>
            <?php
            if ($_SESSION['message']) {
                echo $_SESSION['message'];
            }

            unset($_SESSION['message']);
            ?>
            <br>
            <table>
                <tr>
                    <th class="table_th">Name</th>
                    <th class="table_th">Username</th>
                    <th class="table_th">SSN</th>
                    <th class="table_th">Password</th>
                    <th class="table_th">Delete</th>
                    <th class="table_th">Insert</th>
                    <th class="table_th">GPA</th>


                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['aname']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['username']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['assn']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['user_password']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "<a class='btn btn-danger' onClick=\"javascript:return confirm('Are You Sure To Delete This');\" href='delete.php?student_assn={$info['assn']}'> Delete Student </a>"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "<a class='btn btn-primary' href='update_student.php?student_assn={$info['assn']}'> Insert Data </a>"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "<a class='btn btn-success' href='insert_GPA.php?student_assn={$info['assn']}'> Add GPA </a>"; ?>
                        </td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>