<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>Y.O.S</title>
    <link rel="stylesheet" type="text/css" href="style_me.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>
    <nav>
        <img style="border-radius: 25px 25px 25px 25px;height: 60px;width: 60px;margin-left: 20px; margin-bottom: 12px;" src="UNlogo.png">
        <label class="logo">Y.O.S</label>
        <ul>
            <li><a href="">Home</a></li>
            <li><a href="login.php" class="btn btn-success">Log In</a></li>
            <li><img style="border-radius: 25px 25px 25px 25px;height: 60px;width: 60px;margin-left: 20px; margin-bottom: 12px;" src="Flogo.png"></li>
        </ul>

    </nav>
    <h1 style="padding-top: 240px;">
        <h2></h2>
        <marquee behavior="alternate" direction="left" style="border:BLACK"><h5>Welcome Home</h5></marquee>
        <br><br>
        <marquee direction="right" behavior="alternate" style="border:BLACK">
            <h1 style="padding-bottom: 100px;"> WELCOME TO Y.O.S </h1>
        </marquee>
    </h1>
</body>

</html>