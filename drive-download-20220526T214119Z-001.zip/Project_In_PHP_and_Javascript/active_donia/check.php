<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funda of Web IT</title>
    <?php
    include 'admin_css.php';
    ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">


                <?php
                if (isset($_SESSION['status'])) {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }
                ?>
                <div class="card mt-5">
                    <div class="card-header">
                        <center>
                            <h4>Activate Courses</h4>
                        </center>
                    </div>
                    <div class="card-body">

                        <form action="code.php" method="POST">
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "yos");

                            global $depart;
                            global $sem;
                            global $lvl;
                            if (isset($_GET['btnGetCourses'])) {

                                $depart = $_GET["depart"];
                                $lvl = $_GET["lvl"];
                                $sem = $_GET["sem"];
                            }





                            $courses_query = "SELECT code FROM course WHERE type like '%elective%'and code IN (SELECT course_code FROM include WHERE program_number = '$depart' AND level = '$lvl' AND semester = '$sem')";
                            $query_run = mysqli_query($con, $courses_query);

                            if (mysqli_num_rows($query_run) > 0) {
                                foreach ($query_run as $courses) {
                            ?>
                                    <input type="checkbox" name="courses_list[]" value="<?= $courses['code']; ?>" /> <?= $courses['code']; ?> <br />
                            <?php
                                }
                            } else {
                                echo "NO Records Found!";
                            }
                            ?>
                            <div class="form-group mt-3">
                                <button name="save_multicheckbox" class="btn btn-primary">Save</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>