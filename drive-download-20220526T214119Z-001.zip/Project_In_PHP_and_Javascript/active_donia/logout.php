<?php
session_start();
session_destroy();

header("location:/Project_IN_PHP_AND_JAVASCRIPT/student/login.php");

?>