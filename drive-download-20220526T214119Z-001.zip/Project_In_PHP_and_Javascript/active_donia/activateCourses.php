<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Activate Courses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'admin_css.php';
    ?>
</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <?php
    if (isset($GET['btnGetCourses'])) {

        $depart = $_GET['depart'];
        $lvl = $_GET['lvl'];
        $sem = $_GET['sem'];
    }
    ?>
    <div class="content">
        <form method="GET" action="check.php">
            <h2>Department: </h2>
            <input type="radio" id="cs" name="depart" value="1">
            <label for="cs">CS</label>
            <br>
            <input type="radio" id="ms" name="depart" value="2">
            <label for="ms">MATH-CS</label>
            <br>
            <input type="radio" id="ss" name="depart" value="3">
            <label for="ss">STAT-CS</label>
            <br>


            <h2>Level: </h2>
            <input type="radio" id="lvl-2" name="lvl" value="2">
            <label for="lvl-2">2</label>
            <br>
            <input type="radio" id="lvl-3" name="lvl" value="3">
            <label for="lvl-3">3</label>
            <br>
            <input type="radio" id="lvl-4" name="lvl" value="4">
            <label for="lvl-4">4</label>
            <br>

            <h2>Semseter: </h2>
            <input type="radio" id="sem-1" name="sem" value="1">
            <label for="sem-1">1</label>
            <br>
            <input type="radio" id="sem-2" name="sem" value="2">
            <label for="sem-2">2</label>
            <br><br><br>

            <input type="submit" value="Get Courses" name="btnGetCourses">
        </form>
    </div>
</body>

</html>