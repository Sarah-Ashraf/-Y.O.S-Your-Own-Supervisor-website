<header class="header">
    <nav>
        <img style="border-radius: 25px 25px 25px 25px;height: 60px;width: 60px;margin-right: 10px; margin-bottom: 3px;" src="UNlogo.png">
        <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/adminhome.php" class="aa"> Admin Dashboard </a>
        <div class="logout">
            <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/logout.php" class="btn btn-primary"> Log Out </a>
            <img style="border-radius: 25px 25px 25px 25px;height: 60px;width: 60px;margin-left: 20px; margin-bottom: 3px;" src="Flogo.png">
        </div>
    </nav>

</header>
<aside>
    <ul>
        <li>
            <div class="dropdown">
                <a class="dropbtn"> Student </a>
                <div class="dropdown-content">
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/add_student.php"> Add New Student </a>
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/student/view_students.php"> View Students </a>
                </div>
            </div>
        </li>
        <br><br><br>
        <li>
            <div class="dropdown">
                <a class="dropbtn"> Supervisor </a>
                <div class="dropdown-content">
                    <a href="/Project_In_PHP_and_Javascript/supervisor/add_super.php">Add New Supervisor</a>
                    <a href="/Project_In_PHP_and_Javascript/supervisor/view_super.php">View Supervisors</a>
                </div>
            </div>
        </li>
        <br><br><br>
        <li>
            <div class="dropdown">
                <a class="dropbtn"> Summer Semester </a>
                <div class="dropdown-content">
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/actcour.php">Summer Courses activation</a><!-- Summer Courses activation-->
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/sumer.php">Summer Hours</a>
                    <a href="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/view_opened_courses.php">View Courses</a>
                </div>
            </div>
        </li>
        <br><br><br><br><br><br>    
        <li>
            <a href="/Project_IN_PHP_AND_JAVASCRIPT/active_donia/activateCourses.php"> Courses Activation </a>
        </li>


    </ul>
</aside>