<!DOCTYPE html>
<html>

<head>

  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <meta charset="utf-8">
  <title> Y.O.S </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

  <style>
    .btt {
      width: 150px;
      height: 60px;
      border-radius: 20px;
      font-family: "Raleway", sans-serif;
      background-color: rgb(0, 0, 0);
      color: white;
    }

    .btt:hover {
      background-color: rgb(0, 0, 0);
      color: rgb(214, 29, 5);
    }
  </style>
  <!--<link rel="stylesheet" type="text/css" href="styleACT.css">-->
  <?php
  include 'admin_css.php';
  ?>
</head>

<body>
  <!--<img src="UNlogo.png" align="left"></img>
  <img src="Flogo.png" align="right"></img>-->
  <?php
  include 'admin_sidebar.php';
  ?>
  <!--<ul>
    <li><a href="default.asp">Home</a></li>
    <li><a href="#">Summer</a>
      <ul>
        <li><a href="/Project_IN_PHP_AND_JAVASCRIPT/Acyivate_nada/sumer.php">Update Summer hour </a></li>
        <li><a href="/yourOwnSup/activation/actcour.php">Summer Course Activation</a>
        <li>
      </ul>
    </li>
    <li><a href="contact.asp">Students</a></li>
    <li><a href="about.asp">Supervisor</a></li>
  </ul>-->

  <div class="content">
    <form method="POST">
      <div class="wrapper1">
        <div class="search-input1">
          <a href="" target="_blank" hidden></a>
          <input type="text" placeholder="Type course name " name="code">
          <div class="autocom-box1">
            <!-- here list are inserted from javascript -->
          </div>
          <div class="icon"><i class="fas fa-search"></i></div>
        </div>
      </div>
      <script src="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/suggestions.js"></script>
      <script src="/Project_IN_PHP_AND_JAVASCRIPT/Activate_nada/script.js"></script>

      <input class="bt" type="submit" name="btnupdate" value="Opened">
      <input class="btt" type="submit" name="closeupdate" value="SET ALL CLOSED">

    </form>
  </div>
</body>

</html>


<?php
if (isset($_POST["btnupdate"])) {
  require 'bb.php';
  $codename = $_POST["code"];
  if (empty($codename)) {
    echo '<script type="text/javascript"> alert(" please enter course name") </script>';
  } else {
    $q = "SELECT code from course WHERE code='$codename'";
    $result1 = mysqli_query($con, $q);
    if ($result1 == "") {
      echo '<script type="text/javascript"> alert("ERROR! course name") </script>';
    } else {
      $active1 = TRUE;
      $query1 = " UPDATE course SET activated='$active1' WHERE code='$codename' ";
      $result2 = mysqli_query($con, $query1);
    }
  }
}

if (isset($_POST["closeupdate"])) {
  require 'bb.php';
  $active2 = FALSE;
  $query2 = " UPDATE course SET activated='$active2' ";
  $result3 = mysqli_query($con, $query2);
  if (mysqli_query($con, $query2)) {
    echo '<script type="text/javascript">alert("ALL COURSES CLOSED")</script>';
  }
}
?>
?>