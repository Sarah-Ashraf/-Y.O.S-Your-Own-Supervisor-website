<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title> Y.O.S </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!--<link rel="stylesheet" type="text/css" href="style_me.css">-->

    <?php
    include 'admin_css.php';
    ?>
</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <!--<img src="./images/asu.png" align="left"></img>
     <img src="./images/sci.png" align="right" ></img>-->
    <!--<ul>
  <li><a href="default.asp">Home</a></li>
  <li><a href="#">Summer</a> 
      <ul>
          <li><a href="/yourOwnSup/sumerhour/sumer.php">Update Summer hour </a></li>
          <li><a href="/yourOwnSup/activation/actcour.php">Summer Course Activation</a><li>
      </ul>
   </li>
  <li><a href="contact.asp">Students</a></li>
  <li><a href="about.asp">Supervisor</a></li>
</ul>
<br/>-->

    <div class="content">
        <form method="POST" className='form_deg'>

            <p>Department name :</p>
              <input type="radio" id="cs" name="dep" value="1" />
              <label for="cs">Computer Science</label><br />
              <input type="radio" id="ss" name="dep" value="2" />
              <label for="ss">stat-cs</label><br />
              <input type="radio" id="gs" name="dep" value="3" />
              <label for="ms">Math-cs</label><br />
            <br />
            <p>Level :</p>
              <input type="radio" id="1" name="level" value="1" />
              <label for="1"> 1 </label><br />
              <input type="radio" id="2" name="level" value="2" />
              <label for="2"> 2 </label><br />
              <input type="radio" id="3" name="level" value="3" />
              <label for="3"> 3 </label><br />
              <input type="radio" id="4" name="level" value="3" />
              <label for="4"> 4 </label><br />

            <br />
            <br />

            <label> Hours number : </label>
            <select name="hour" id="hour">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>

            <br /><br />
            <input type="submit" name="btnupdate" value="UPDATE">
            <br />

        </form>
    </div>
</body>

</html>

<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "yos";

//  $con= mysqli_connect($dbhost,$dbuser,$dbpass,$db);
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $db);
if (mysqli_connect_errno()) {
    echo "failed";
    exit();
}
if (isset($_POST["btnupdate"])) {

    if ((empty($_POST["level"])) || (empty($_POST["dep"])) || (empty($_POST["hour"]))) {
        echo ' <script type="text/javascript">alert(" please enter all data") </script>';
    } else {
        $level = $_POST["level"];
        $dep = $_POST["dep"];
        $hour = $_POST["hour"];
        $query = "UPDATE prog_summers SET hours='$hour' WHERE program_number= '$dep' and level='$level' ";
        $stat = $con->prepare($query);
        $stat->execute();
        if (mysqli_query($con, $query)) {
            echo ' <script type="text/javascript">alert(" Record updated successfully")</script>';
        } else {
            echo ' <script type="text/javascript">alert(" Record Not updated successfully")</script>';
        }
    }
}


?>