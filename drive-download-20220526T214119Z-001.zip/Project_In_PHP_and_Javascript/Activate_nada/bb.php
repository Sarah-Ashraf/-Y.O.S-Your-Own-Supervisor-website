
  <?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "yos";


   
      $con = mysqli_connect("localhost","root","","yos");
      if($con -> connect_error){
          die("Connection Failed:". $con-> connect_error);
      }

    

  
   /*function f($x){
    $i; 
    $query2="select code from course";
    $stat=$con->query($query2);
    foreach($stat as $row)
    {
       if ($row["code"]==$x)
         $i=1;
       else
         $i=0;
       return $i;
    }

  }*/

?>