<?php

error_reporting(0);
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM course  ";

$result = mysqli_query($data, $sql);

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Courses</title>
    <?php
    include 'admin_css.php';
    ?>
    <style type="text/css">
        .table_th {
            width: 20%;
            /*font-size: 20px;*/
            text-align: center;
            color: black;
            background-color: skyblue;
            font-size: 15px;

        }

        .table_td {
            padding: 9px;
            background-color: white;
            /*padding-left: 15px;*/
            font-size: 15px;
            /*text-align: left;*/
            /*padding-right: 20px;*/
            /*width: 15px;*/
            /*width: fit-content;*/
        }

        table,
        th,
        td {
            border: 1px solid black;
            /*width: fit-content;*/
            height: 50px;
            /*font-size: 15px;*/
            margin-left: -2%;
            margin-right: 2%;
            text-align: center;
        }
    </style>


</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <h1 style="font-size: 37px;">Courses</h1>

            <?php
            if ($_SESSION['message']) {
                echo $_SESSION['message'];
            }

            unset($_SESSION['message']);
            ?>
            <br>
            <table>
                <tr>
                    <th class="table_th">Course Code</th>
                    <th class="table_th">Course Name</th>
                    <th class="table_th">Course Hours</th>
                    <th class="table_th">Course Type</th>
                    <th class="table_th">Activativation</th>




                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['code']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['name']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['credithour']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['type']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php

                            if ("{$info['activated']}" == '0') {
                                echo "No";
                            } else if ("{$info['activated']}" == '1') {
                                echo "Yes";
                            }
                            ?>

                        </td>

                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>

<?php
if (isset($_POST["btnupdate"])) {
    require 'bb.php';
    $codename = $_POST["code"];
    if (empty($codename)) {
        echo '<script type="text/javascript"> alert(" please enter course name") </script>';
    } else {
        $q = "SELECT code from course WHERE code='$codename'";
        $result1 = mysqli_query($con, $q);
        if ($result1 == "") {
            echo '<script type="text/javascript"> alert("ERROR! course name") </script>';
        } else {
            $active1 = TRUE;
            $query1 = " UPDATE course SET activated='$active1' WHERE code='$codename' ";
            $result2 = mysqli_query($con, $query1);
        }
    }
}

?>