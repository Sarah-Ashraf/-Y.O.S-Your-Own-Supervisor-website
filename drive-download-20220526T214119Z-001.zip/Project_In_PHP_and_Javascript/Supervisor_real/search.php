<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";


$data = mysqli_connect($host, $user, $password, $db);



/*$sql = "SELECT student.stname,student.phone,student.level,student.gpa,student.acadamiccode,student.passed_hours,supervisor.supssn FROM student,supervisor where student.supervisor_supssn=supervisor.supssn and supervisor.supssn=$sup_sssn ";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();

$sql8 = "SELECT supusername FROM supervisor where supssn=$sup_sssn";
$result8 = mysqli_query($data, $sql8);
$info8 = $result8->fetch_assoc();*/
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Search</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>

   <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>average</title>
</head>

   <body>
       
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-header">
                        <h4>Average Degrees </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">

                                <form action="" method="GET">
                                    <div class="input-group mb-3">
                                        <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                        <button type="submit" class="btn btn-primary">Search</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Course Code</th>
                                    <th>year</th>
                                    <th>Average</th>
                                    <th>Total Marks</th>


                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $con = mysqli_connect("localhost","root","","yos");

                                    if(isset($_GET['search']))
                                    {
                                        $filtervalues = $_GET['search'];
                                        $query = "SELECT course_code, year, FORMAT(avg(mark),3) , hours*50 FROM reg WHERE CONCAT(course_code,year) LIKE '%$filtervalues%'group by (course_code) order by avg(mark) desc";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['course_code']; ?></td>
                                                    <td><?= $items['year']; ?></td>
                                                    <td><?= $items['FORMAT(avg(mark),3)']; ?></td>
                                                    <td><?= $items['hours*50']; ?></td>

                                                 
                                                    
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>