<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);
$username = $_GET['us'];
$sql8 = "SELECT supssn FROM supervisor where supusername='$username' ";
$result8 = mysqli_query($data, $sql8);

$sql = "SELECT student.*,supervisor.* FROM student,supervisor where supusername='$username' and student.supervisor_supssn=supervisor.supssn";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();


?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Home</title>
      <link rel="stylesheet" href="sup.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>

   <body>
    
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class='active' href='#'> Home </a> </li> <!--ssn-->

         <li> <?php echo "<a class='active' href='mystudents.php?ssn={$info['supssn']}'> My Students</a> ";?> </li>

            <li><a class="active" href="search.php">Average Degrees</a></li>

            <li><a class="active" href="/website/logout.php">LOGOUT</a></li>
         </ul>
     </nav>

           <table class="two">
                <tr>
                    <th>Name : </th>
                    <td><?php echo "{$info['supname']}"; ?></td>
                </tr>

                <tr>
                    <th>SSN : </th>
                    <td><?php echo "{$info['supssn']}"; ?></td>
                </tr>
                <tr>
                    <th>Username : </th>
                    <td><?php echo "{$info['supusername']}"; ?></td>
                </tr>
               
                <tr>
                    <th>Email : </th>
                    <td><?php echo "{$info['supemail']}"; ?></td>
                </tr>
            </table>

</body>
</html>