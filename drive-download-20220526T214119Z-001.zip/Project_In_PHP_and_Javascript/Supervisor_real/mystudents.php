<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";


$data = mysqli_connect($host, $user, $password, $db);

$sup_sssn = $_GET['ssn'];

$sql = "SELECT student.stname,student.phone,student.level,student.gpa,student.acadamiccode,student.passed_hours,supervisor.supssn FROM student,supervisor where student.supervisor_supssn=supervisor.supssn and supervisor.supssn=$sup_sssn ";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();

$sql8 = "SELECT supusername FROM supervisor where supssn=$sup_sssn";
$result8 = mysqli_query($data, $sql8);
$info8 = $result8->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>My Students</title>
      <link rel="stylesheet" href="sup.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>

   <body>
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
       <!--   <a class="active" href="superhome.php">Home</a></li>ssn-->
         <li><?php echo "<a class='active' href='superhome.php?us={$info8['supusername']}'>Home </a> ";?>  </li> 
            <li><a class='active' href="#" >My Students </a> </li>

            <li><a class='active' href='search.php'>Average Degrees</a></li>
            <li><a class="active" href="/website/logout.php">LOGOUT</a></li>
         </ul>
     </nav>

    <table class="one">
            <tr>
                    <td>
                        <?php echo  "<a href='view1.php?ssn={$info['supssn']}'>"; ?>
                        <p >Level 1 <br><br> Number of Students : 
                        <?php $sql3 = "SELECT count(student.ssn) from student,supervisor where student.supervisor_supssn = supervisor.supssn and supervisor.supssn=$sup_sssn and student.level='1'; ";
                          $result3 = mysqli_query($data, $sql3);
                                                                                $info3 = $result3->fetch_assoc();
                                                                                //print_r($info3);
                                                                                echo "{$info3['count(student.ssn)']}";
                                                                                ?></p>
                        </a>
                    </td>
                    <td>
                        <?php echo  "<a href='view2.php?ssn={$info['supssn']}'>"; ?>
                        <p>Level 2 <br><br> Number of Students : <?php $sql4 = "SELECT count(student.ssn) from student,supervisor where student.supervisor_supssn = supervisor.supssn and supervisor.supssn=$sup_sssn and student.level='2'; ";
                                                                                $result4 = mysqli_query($data, $sql4);
                                                                                $info4 = $result4->fetch_assoc();
                                                                                //print_r($info3);
                                                                                echo "{$info4['count(student.ssn)']}";
                                                                                ?></p>
                        </a>
                    </td>
            </tr>
                <tr>
                    <td>
                    <?php echo  "<a href='view3.php?ssn={$info['supssn']}'>";?>
                            <p >Level 3 <br><br> Number of Students : <?php $sql5 = "SELECT count(student.ssn) from student,supervisor where student.supervisor_supssn = supervisor.supssn and supervisor.supssn=$sup_sssn and student.level='3'; ";
                                                                                    $result5 = mysqli_query($data, $sql5);
                                                                                    $info5 = $result5->fetch_assoc();
                                                                                    //print_r($info3);
                                                                                    echo "{$info5['count(student.ssn)']}";
                                                                                    ?></p>
                        </a>
                    </td>
                    <td>
                    <?php echo  "<a href='view4.php?ssn={$info['supssn']}'>";?>
                            <p >Level 4 <br><br> Number of Students : <?php $sql6 = "SELECT count(student.ssn) from student,supervisor where student.supervisor_supssn = supervisor.supssn and supervisor.supssn=$sup_sssn and student.level='4'; ";
                                                                                    $result6 = mysqli_query($data, $sql6);
                                                                                    $info6 = $result6->fetch_assoc();
                                                                                    //print_r($info3);
                                                                                    echo "{$info6['count(student.ssn)']}";
                                                                                    ?></p>
                        </a>
                    </td>
         </tr>
     </table>
</body>
</html>