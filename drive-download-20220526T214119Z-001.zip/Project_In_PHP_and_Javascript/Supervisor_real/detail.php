
<?php

error_reporting(0);
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$st_acdno = $_GET['acno'];

$data = mysqli_connect($host, $user, $password, $db);
$sql = "SELECT course_code, name, mark, grade, year, semester from reg , course where reg.course_code = course.code and reg.course_type = course.type and student_ssn =(select ssn from student where acadamiccode=$st_acdno) order by year asc,semester desc ";
$result = mysqli_query($data, $sql);

//$sql3 = "SELECT ssn From student where";
//$result = mysqli_query($data, $sql3);

$sql9= "SELECT student.supervisor_supssn ,supervisor.supusername From student,supervisor where supervisor_supssn=supssn and acadamiccode='$st_acdno' ";
$result9 = mysqli_query($data, $sql9);
$info9 = $result9->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Details</title>
   
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

      <style type="text/css">
          *{
    margin: 0;
    padding: 0;
    list-style: none;
    text-decoration: none;
  }

          body{
    margin: 0;
    padding: 0;
    font-family: sans-serif;

  }

nav .logo{
    font-weight: bold;
    line-height: 60px;
    padding-left: 80px;
    color: #FFB344;
    font-size: 35px;
    font-family: Arial;
    float: left;

}

nav{
    margin: 0;
    padding: 0;
    height: 60px;
    background: #020202;
}

nav ul{
    float: left; 
    justify-content: center;
    align-items: center;
    margin-left: 40px;
}
nav ul li{
    display: inline-block;
  }
  nav ul li a{

    color: #FFF8E5;
    display: block;
    padding: 0 15px;
    line-height: 65px;
    font-family: Arial;
    font-weight: bold;
    transition: 0.4s ease-in-out;
  }
  nav ul li a:hover{
    color: #FFB344;
  }

  table {
                background: linear-gradient(to top, rgba(0, 0, 0, 0.8)50%,rgba(0,0,0,0.8)50%);
                padding-top: 15px;
                padding-bottom: 15px;
                padding-right: 8px;
                padding-left: 8px;
                border-style:solid ;
                width: 95%;
                height:80%;
                border-color: #312c27;
                border-radius:  20px;
            }
            /*tr{
                border-style: solid ;
                border-color: #0e2e4e;
            }*/
            th {
                text-align: center;
                width: 150px;
                height: 10px;
                color: #ff7200;
                font-family: Arial;
                font-size: 18px;
                font-weight: bold;
            }
            td {
                text-align: center;
                width: 150px;
                height: 10px;
                color: rgb(214, 212, 226);
                font-family: Arial;
                font-size: 14px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            td a {
                color: #FFF8E5;
            }
            td a:hover {
                color: #FFB344;
            }
         h2 {
            color: #FFF8E5;
        }
    </style>

   </head>

  
    
     
<body>
<nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><?php echo "<a class='active' href='superhome.php?us={$info9['supusername']}'>Home </a> ";?></li> <!--ssn-->

        
        <li> <?php echo "<a class='active' href='mystudents.php?ssn={$info9['supervisor_supssn']}'>My Students </a> ";?></li>
            <li><a class="active" href="search.php">Average Degrees</a></li>

            <li><a class="active" href="/website/logout.php">LOGOUT</a></li>
         </ul>
     </nav>


    
     <center>

        <table>
                <tr>
                    <th colspan="6" ><h2>Details<h2></th>
                </tr>
      </table>
            <br>
            <table >
                <tr>
                    <th class="table_th">Course Code</th>
                    <th class="table_th">Name</th>
                    <th class="table_th">Mark</th>
                    <th class="table_th">Grade</th>
                    <th class="table_th" style="padding: 5px;">Year</th>
                    <th class="table_th" style="padding: 5px;">Semester</th>
                </tr>

           <?php
                while ( $info = $result->fetch_assoc() ) 
                {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['course_code']}"; ?>
                        </td>

                        <td class="table_td">
                            <?php echo "{$info['name']}"; ?>
                        </td>


                        <td class="table_td">
                            <?php echo "{$info['mark']}"; ?>
                        </td>

                        <td class="table_td">
                            <?php echo "{$info['grade']}"; ?>
                        </td>

                        <td class="table_td">
                            <?php echo "{$info['year']}"; ?>
                        </td>

                        
                        <td class="table_td">
                            <?php
                            if ("{$info['semester']}" == '1') {
                                echo "Fall";
                            } else if ("{$info['semester']}" == '2') {
                                echo "Spring";
                            } else if ("{$info['semester']}" == '3') {
                                echo "Summer";
                            }
                            ?>
                        </td>         
                    </tr>
                <?php
              }
            ?>         
       
        <?php 
        $data = mysqli_connect($host, $user, $password, $db);

        $sql1 = "SELECT ssn From student where acadamiccode='$st_acdno'"; 
        $result1 = mysqli_query($data, $sql1);
        $info1 = $result1->fetch_assoc();     
        $x= $info1['ssn'] ;
        

        $sql5 = "CALL total_gpa($x)"; // call procedure
        $result5 = mysqli_query($data, $sql5);
       /* if($result5)
        {echo "1";}
        else{echo "0";}*/

        $info5 = $result5->fetch_assoc();
        $y= $info5['format(@ptH/@totalH,4)'] ;
        

        ?>
        <tr>
            <?php echo "<th colspan='6' ><h3> GPA is $y <h3></th>";?>
        </tr>
 </table>
        </center>
  
</body>

</html>