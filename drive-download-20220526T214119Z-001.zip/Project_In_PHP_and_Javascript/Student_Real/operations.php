<?php


?>
<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

//$student_sssn = $_GET['ssn'];
//$username = $_SESSION['username'];
//$pass=$_SESSION['password'];

/* if (isset($_SESSION['username'], $_SESSION['password'])) { */ /// Retrive username
    $ssnn = $_GET['ssnn'];
    $sql = "SELECT * FROM student where ssn='$ssnn'";

    $result = mysqli_query($data, $sql);

    $info = $result->fetch_assoc();
/* } */
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="student.css" />
    <title>Y.O.S</title>
</head>

<body>
    <nav>
        <div class="logo">
            <img src="UNlogo.png" />
            <h4>Y.O.S</h4>
        </div>
        <ul class="nav-item">
            <li class="nav-item">
                <a href="/Project_IN_PHP_AND_JAVASCRIPT/Student_Real/studenthome.php" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <button class="dropbtn">MY</button>
                    <div class="dropdown-content">
                        <a href="#">INFO</a>
                        <a href="#">Academic Points</a>
                        <a href="/Project_IN_PHP_AND_JAVASCRIPT/Student_Real/operations.php">Electronic Operation</a>

                    </div>
                </div>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <button class="dropbtn">Academic Degrees</button>
                    <div class="dropdown-content">
                        <a href="gpa_2018.html">2018 - 2019</a>
                        <a href="gpa_2019.html">2019 -2020</a>
                        <a href="gpa_2020.html">2020 - 2021</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a href="#" class="nav-link">About Academic Guideness</a>
            </li>
            <li>
                <button class="btn3"><a href="/Project_IN_PHP_AND_JAVASCRIPT/Student/logout.php">Log Out</a></button>
            </li>
        </ul>
        <div class="logo">
            <img src="Flogo.png" />
        </div>
    </nav>

</body>
<section class="student">
    <div class="student-section">
        <div class="content">
            <table style="width: 100%">
                <tr>
                    <th style="width: 100%">
                        <!--<a href="/Project_IN_PHP_AND_JAVASCRIPT/Student_Real/Regesteration_form.php">Electronic Regesteration</a>-->
                        <?php echo "<a class='btn btn-success'  href='/Project_IN_PHP_AND_JAVASCRIPT/Student_Real/Regesteration_form.php?ssn={$info['ssn']}'>Electronic Regesteration </a>"; ?>
                    </th>
                    <td></td>
                </tr>
                <tr>
                    <th></th>
                    <td></td>


                </tr>
                <tr>
                    <th></th>
                    <td></td>

                </tr>
                <tr>
                    <th></th>
                    <td></td>

                </tr>
            </table>

        </div>

</section>

</html>