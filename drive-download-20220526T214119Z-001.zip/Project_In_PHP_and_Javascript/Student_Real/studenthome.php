<?php
session_start();
session_destroy();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);
$username = $_GET['us'];

$sql8 = "SELECT ssn FROM student where stusername='$username' ";
$result8 = mysqli_query($data, $sql8);
$info8 = $result8->fetch_assoc();

$sql = "SELECT student.*,supervisor.supemail,supervisor.supname FROM student,supervisor where stusername='$username' and student.supervisor_supssn=supervisor.supssn";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Home</title>
      <link rel="stylesheet" href="/project_in_php_and_javascript/Supervisor_real/sup.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<style>

.two {
    background: linear-gradient(to top, rgba(0, 0, 0, 0.8)50%,rgba(0,0,0,0.8)50%);
    border-style:solid ;
    width: 63%;
    height:70%;
    align-items: center;
    margin-top: 120px;
    border-color: #312c27;
    border-radius:  20px;
    margin-left: 20px;
}

.two th {
    text-align: left;
    width: 80px;
    height: 40px;
    color: #FFB344;
    font-family: Arial;
    font-size: 18px;
    padding-left: 100px;
    font-weight: bold;
}
.two td {
    text-align: left;
    width: 80px;
    height: 60px;
    color: rgb(214, 212, 226);
    font-family: Arial;
    font-size: 16px;
    font-weight: bold;
    margin-top: 10px;
}

      .btnn{
    width: 230px;
    height: 95px;
    background: #ff7200;
    border: none;
    margin-top: 15px;
    margin-left: 40px;
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color: rgb(7, 7, 7);
    transition: 0.4s ease;
    font-weight: bold;
   
  }
  .btnn:hover{
    background: #080808;
    color: #FFB344;
  }
  </style>
   </head>

<body>
<nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class='active' href='#'> Home </a> </li> <!--ssn-->

         <li> <?php echo "<a class='active' href='Regesteration_form.php?ssn={$info['ssn']}'> Registeration </a> ";?> </li>

            <li><?php echo "<a class='active' href='academicbook.php?ssn={$info8['ssn']}'> Academic Degrees </a>";?></li>

            <li><a class="active" href="/website/logout.php">LOGOUT</a></li>
         </ul>
     </nav>


<section>
    <div >
        <div>
            <table class="two">
                <tr>
                    <th>Name :</th>
                    <td><?php echo "{$info['stname']}"; ?></td>
                </tr>
                <tr>
                    <th>Program :</th>
                    <td> <?php
                            if ("{$info['program_number']}" == '1') {
                                echo "Computer Science";
                            } else if ("{$info['program_number']}" == '2') {
                                echo "STAT_CS";
                            } else if ("{$info['program_number']}" == '3') {
                                echo "MATH_CS";
                            }
                            ?></td>

                    <td ><button  class="btnn"><a href="studentSubject.html"><!-------  ------>
                                <p id="rcorners1">Number of Courses : <?php $sql3 = "SELECT count(course_code) from reg where student_ssn = ( select ssn from student where stusername = '$username') and year='2020' and semester='2'";
                                                                        $result3 = mysqli_query($data, $sql3);
                                                                        $info3 = $result3->fetch_assoc();
                                                                        //print_r($info3);
                                                                        echo $info3['count(course_code)'];
                                                                        ?></p>
                                
                            </a></button></td>
                </tr>
                <tr>
                    <th>Level :</th>
                    <td><?php echo $info['level']; ?></td>

                </tr>
                <tr>
                    <th>Phone :</th>
                    <td><?php echo $info['phone']; ?></td>
                    <br>
                </tr>
                <tr>
                    <th>Academic Number :</th>
                    <td><?php echo $info['acadamiccode']; ?></td>
                    <td ><button class="btnn"><a href="#">Academic Supervisor Email: <br><br><?php echo $info['supemail'] ?></a></button></td>
                </tr>
                <tr>
                    <th>Supvisor Name :</th>
                    <td><?php echo $info['supname']; ?></td>

                </tr>
            </table>

        </div>

</section>
</body>
</html>