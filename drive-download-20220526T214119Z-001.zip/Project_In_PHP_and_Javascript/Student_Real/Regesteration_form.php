<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";


$data = mysqli_connect($host, $user, $password, $db);


global $ssn;
$ssn = $_GET['ssn'];
$sql1 = " SELECT student.*,supervisor.supname,supervisor.supssn from student,supervisor where ssn='$ssn' and student.supervisor_supssn=supervisor.supssn";

$result = mysqli_query($data, $sql1);
$info = $result->fetch_assoc();



?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
   
      <title>Reg</title>
      <link rel="stylesheet" href="/project_in_php_and_javascript/Supervisor_real/sup.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <style type="text/css">
          *{
    margin: 0;
    padding: 0;
    list-style: none;
    text-decoration: none;
  }

          body{
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background-color:skyblue;
    background: linear-gradient(to top, rgba(0,0,0,0.5)50%,rgba(0,0,0,0.5)50%), url(2.jpg); 


  }

nav .logo{
    font-weight: bold;
    line-height: 60px;
    padding-left: 80px;
    color: #FFB344;
    font-size: 35px;
    font-family: Arial;
    float: left;

}

nav{
    margin: 0;
    padding: 0;
    height: 60px;
    background: #020202;
}

nav ul{
    float: left; 
    justify-content: center;
    align-items: center;
    margin-left: 40px;
}
nav ul li{
    display: inline-block;
  }
  nav ul li a{

    color: #FFF8E5;
    display: block;
    padding: 0 15px;
    line-height: 65px;
    font-family: Arial;
    font-weight: bold;
    transition: 0.4s ease-in-out;
  }
  nav ul li a:hover{
    color: #FFB344;
  }

  table {
                background: linear-gradient(to top, rgba(0, 0, 0, 0.8)50%,rgba(0,0,0,0.8)50%);
                padding-top: 15px;
                padding-bottom: 15px;
                padding-right: 8px;
                padding-left: 8px;
                border-style:solid ;
                width: 95%;
                height:80%;
                border-color: #312c27;
                border-radius:  20px;
            }
            /*tr{
                border-style: solid ;
                border-color: #0e2e4e;
            }*/
            th {
                text-align: center;
                width: 150px;
                height: 10px;
                color: #ff7200;
                font-family: Arial;
                font-size: 18px;
                font-weight: bold;
            }
            td {
                text-align: center;
                width: 150px;
                height: 10px;
                color: rgb(214, 212, 226);
                font-family: Arial;
                font-size: 14px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            td a {
                color: #FFF8E5;
            }
            td a:hover {
                color: #FFB344;
            }
         h2 {
            color: #FFF8E5;
            padding-right:60px;
            text-align:center;
        }
    </style>

</head>

<body>
<nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><?php echo "<a class='active' href='studenthome.php?us={$info['stusername']}'>Home </a> ";?></li> <!--ssn-->

         <li> <a class='active' href='#'> Registeration </a> </li>

            

            <li><a class="active" href="/website/logout.php">LOGOUT</a></li>
         </ul>
     </nav>

    <div>
        <center>

            <div>
                <div>
                    
                    <th colspan="7" ><h2>Regestiration Form</h2></th>
                </div>
            </div>
            <br>
            <table>
                <form method="POST">
                    <tr>
                        <th>Acd.No.</th>
                        <td >
                            <input name="acadamiccode" value=" <?php echo "{$info['acadamiccode']}"; ?>" readonly>
                        </td>

                        <th>Name</th>
                        <td >
                            <input name="stname" value=" <?php echo "{$info['stname']}"; ?>" readonly>
                        </td>

                        <th >SSN</th>
                        <td >
                            <input name="ssn" value="<?php echo "{$info['ssn']}"; ?>" readonly>
                        </td>

                    <tr >

                        <th style="padding: 5px;">Level</th>
                        <td >
                            <input name="level" value="<?php echo "{$info['level']}"; ?>" readonly>
                        </td>

                        <th  style="padding: 5px;">Program</th>
                        <td >
                            <input name="program_number" value="<?php
                                                                if ("{$info['program_number']}" == '1') {
                                                                    echo "Computer Science";
                                                                } else if ("{$info['program_number']}" == '2') {
                                                                    echo "STAT_CS";
                                                                } else if ("{$info['program_number']}" == '3') {
                                                                    echo "MATH_CS";
                                                                }
                                                                ?>" readonly>
                        </td>
                        <th style="margin: 5px;">Supervisor Name</th>
                        <td >
                            <input name="supervisor_supssn" value=" <?php if ($info['supervisor_supssn']) {
                                                                        echo $info['supname'];
                                                                    } ?>" readonly>
                        </td>
                    </tr>

                    <tr>
                    </tr>


            </table>
            <h1>Opened Courses</h1>

            <?php
            $sql5 = "CALL new_procedure($ssn)"; // call procedure
            $result5 = mysqli_query($data, $sql5);
            while ($info5 = $result5->fetch_assoc()) {
            ?>
                <div >

                    <label class="option_item">
                        <input type="checkbox" class="checkbox" name="courses_list[]" value="<?= $info5['code']; ?>" />
                        <div class="option_inner">
                            <div class="tickmark"></div>
                            <!--<div class="icon"></div>-->
                            <div name="course_code" class="name"><?php echo "{$info5['name']}\n <br> {$info5['code']}<br> <br>{$info5['credithour']} hours <br> <br>Type is {$info5['type']}";
                                                                    ?></div>
                        </div>
                </div>
            <?php
            }

            ?>

            <br><br><br>
            <table>
                <tr>
                    <td><button name="register" class="btn btn-primary">Save</button></td>

                </tr>
            </table>

        </center>

        </form>
</body>

</html>
<?php
if (isset($_POST['register'])) {
    $data = mysqli_connect($host, $user, $password, $db);

    $ssn = $_GET['ssn'];
    $list = $_POST['courses_list'];

    if (mysqli_connect_errno()) {
        echo "failed";
        exit();
    }
    foreach ($list as $course) {
        $sql2 = " INSERT INTO reg ( student_ssn , course_code ) VALUES ( $ssn ,'$course') ";
        $result8 = mysqli_query($data, $sql2);
    }
    if ($result8) {

        echo ' <script type="text/javascript">alert(" Data Inserted Successfully")</script>';
    } else {
        echo ' <script type="text/javascript">alert(" Faild Registeration")</script>';
    }
}

?>