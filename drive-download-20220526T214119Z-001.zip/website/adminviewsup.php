<?php

error_reporting(0);
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM supervisor";

$result = mysqli_query($data, $sql);

?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
      <meta charset="utf-8">
      <title>View Supervisors</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/><title> Y.O.S </title>
    
    <style type="text/css">
        nav .logo{
            font-weight: bold;
            line-height: 60px;
            padding-left: 80px;
            color: #ff7200;
            font-size: 35px;
            font-family: Arial;
            float: left;
             }
            nav{
                margin: 0;
                padding: 0;
                height: 60px;
                background: #0e2e4e;
            }
            nav ul{
                float: left; 
                justify-content: center;
                align-items: center;
                margin-left: 40px;
            }
            nav ul li{
                display: inline-block;
            }
            nav ul li a{
                color: white;
                display: block;
                padding: 0 15px;
                line-height: 65px;
                font-family: Arial;
                transition: 0.4s ease-in-out;
            }
            nav ul li a:hover{
                color: #ff7200;
            }
            nav ul ul{
                position: absolute;
                top: 60px;
                border-top: 2px solid #ff7200;
                opacity: 0;
                visibility: hidden;
                z-index: 1;
            }
            nav ul li:hover > ul{
                top: 60px;
                opacity: 5;
                display: block;
                visibility: visible;
                transition: .1s ease-in-out;
            }
            nav ul ul li{
                width:215px;
                display: list-item;
                position: relative;
                border: 1px solid #fff;
                border-top: none;
                background: #0e2e4e;
            }
            nav ul ul li a{
                line-height: 50px;
                color: #fff;
            }
            nav ul ul li a:hover{
                line-height: 50px;
                color: #fc7405;
                background: #0f4072;
                }
            nav ul ul li a i{
                margin-left: 45px;
            }
           *{
                margin: 0;
                padding: 0;
                list-style: none;
                text-decoration: none;
            }
            body{
                margin: 0;
                padding: 0;
                font-family: sans-serif;
                background-color: #FEB139;
            }
             table {
                background: linear-gradient(to top, rgba(0, 0, 0, 0.8)50%,rgba(0,0,0,0.8)50%);
                padding-top: 15px;
                padding-bottom: 15px;
                padding-right: 8px;
                padding-left: 8px;
                border-style:solid ;
                width: 95%;
                height:80%;
                border-color: #312c27;
                border-radius:  20px;
            }
            /*tr{
                border-style: solid ;
                border-color: #0e2e4e;
            }*/
            th {
                text-align: center;
                width: 150px;
                height: 40px;
                color: #ff7200;
                font-family: Arial;
                font-size: 18px;
                font-weight: bold;
            }
            td {
                text-align: center;
                width: 170px;
                height: 60px;
                color: rgb(214, 212, 226);
                font-family: Arial;
                font-size: 16px;
                font-weight: bold;
                margin-top: 10px;
            }


            .btnn{
                width: 100px;
                height: 30px;
                background: #ff7200;
                border: none;
                margin-top: 8px;
                font-size: 16px;
                border-radius: 10px;
                cursor: pointer;
                transition: 0.4s ease;
            }
            .btnn:hover{
                background: rgb(0, 0, 0);
            }
            .btnn a{
                text-decoration: none;
                color: rgb(241, 234, 234);
                font-size: 16px;
            }
    </style>
</head>
<body>
    <div class="main"> 
    <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
                  
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="#">View Supervisor</a></li>
                  
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>
    <div class="content">
        <center>
            <br>
            <?php
            if ($_SESSION['message']) {
                echo $_SESSION['message'];
            }

            unset($_SESSION['message']);

            ?>
            <br>
            <table>
                <tr>
                    <th class="table_th">Name</th>
                    <th class="table_th">National ID</th>
                    <th class="table_th">Username</th>
                    <th class="table_th">Password</th>
                    <th class="table_th">Email</th>
                    <th class="table_th">Delete</th>
                    <th class="table_th">Insert</th>
                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['supname']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['supssn']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['supusername']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['suppassword']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['supemail']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "<button class='btnn'><a onClick=\"javascript:return confirm('Are You Sure To Delete This');\" href='admindelsup.php?supervisor_assn={$info['supssn']}'>Delete</a></button>"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "<button class='btnn'><a href='adminupsup.php?supervisor_assn={$info['supssn']}'>Update</a></button>"; ?>
                        </td>
                        
                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>