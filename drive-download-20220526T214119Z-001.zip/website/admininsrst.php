<?php
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "supervisor") {
    header("location:login.php");
}*/

$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$student_sssn = $_GET['ssn'];

$sql = "SELECT course.code,student.stname,student.ssn,course.name,reg.mark,reg.hours FROM reg,student,course where student_ssn=$student_sssn and student_ssn=ssn  and course_code=code";

$result = mysqli_query($data, $sql);

$info = $result->fetch_assoc();

global $result2;
if (isset($_POST['insert_Courses_Degrees'])) {
    $course_code = $_POST['course_code'];
    //$student_ssn = $_POST['student_ssn'];
    //$student_stname = $_POST['stname'];
    //$attempt = $_POST['attempt'];
    $Course_mark = $_POST['mark'];
    $hours = $_POST['hours'];
    //$course_name = $_POST['course_name'];
    //$grade = $_POST['grade'];
    //$year = $_POST['year'];
    //$semester = $_POST['semester'];
    //$typeofreg = $_POST['typeofreg'];

    /* foreach ($course_code as $code) {
        foreach ($Course_mark as $mark) {
 */
    for ($i = 0; $i < count($course_code); $i++) {
        if (!empty($_POST['mark'])) {
            if (($Course_mark[$i] >= 0 and $Course_mark[$i] <= $hours[$i]*50) or ($hours[$i] == 0 and $Course_mark[$i] >= 0 and $Course_mark[$i] <= 50)){
                $sql2 = "UPDATE reg SET mark=$Course_mark[$i] WHERE student_ssn=$student_sssn and course_code='$course_code[$i]' and attempt = (select count('$course_code[$i]') from reg where student_ssn = $student_sssn and course_code='$course_code[$i]') ";
                $result2 = mysqli_query($data, $sql2);
            }
            else{
                echo ' <div class="alert alert-danger" type="text/javascript">Enter Valid Number</div>';
               }
        }
        else {
            //echo " Please enter all fields";
            echo ' <div class="alert alert-danger" type="text/javascript">Please enter all fields !!!!</div>';
            }
        //}
    }



if ($result2) {
    /*echo "<script type='text/javascript'>
        alert('Data Inserted Successfully');
        </script>";*/
    echo ' <div class="alert alert-success" type="text/javascript">Data Inserted Successfully</div>';
} else {
    //echo "Faild Insertion";
    echo ' <div class="alert alert-danger" type="text/javascript">Faild Insertion !!!!</div>';

} 
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Insert Student</title>
 
    <style type="text/css">
        label {
            display: inline-block;
            text-align: left;
            width: 125px;
            padding-top: 10px;
            padding-bottom: 10px;
            padding-left: 10px;
        }

        .div_deg {
            background-color: skyblue;
            /*width: 400px;*/
            padding-top: 40px;
            padding-bottom: 40px;
            border-style: solid;
            border-color: black;
            width: 59%;
            /*border-radius: 25px 25px 25px 25px;*/
        }
    </style>


</head>

<body>


    <div class="content">
        <center>
            <h1 style="font-size: 37px;">Insert Student's Courses & Degrees</h1>
            <table class="div_deg" style="border: 2px solid black; margin-left: -2%; margin-right: 2%; text-align: left;">
                <div>
                    <form action="#" method="POST">
                        <tr>
                            <div class="add_int">
                                <th style="padding-left: 20px;" colspan="2"><label>Student Name</label></th>
                                <td colspan=""><input style=" margin-right: 50px; height: 40px; text-align: center; border-radius: 9px; background-color: white; font-weight: bold;" class="input" type="text" name="stname" value="<?php echo $info['stname']; ?>"></td>

                                <th colspan="2" style="padding-right: 100px; margin-right: 50px;"><label>Student SSN</label></th>
                                <td colspan=""><input style="margin-left: -90px; padding-left: 10px; height: 40px;  text-align: center; border-radius: 9px; background-color: white; font-weight: bold;" class="input" type="number" name="student_ssn" value="<?php echo $info['ssn'] ?>"></td>

                            </div>
                        </tr>

                        <tr>
                            <th></th>

                            <th style="text-align: center; padding-left: 20px;"><label>Course Code</label></th>
                            <th style="text-align: center;"><label>Course Name</label></th>
                            <th style="text-align: center; padding-left: 20px;"><label>Credit Hours</label></th>
                            <th style="text-align: center; padding-left: 20px;"><label>Mark</label></th>
                        </tr>

                        <tr>

                        </tr>
                        <?php
                        //$sql8 = "select count(course_code) from reg where student_ssn=$student_sssn";
                        // $result8 = mysqli_query($data, $sql8);
                        // $row8 = mysqli_fetch_array($result);

                        //------------------dieaa
                        $sql5 = "SELECT code,stname,ssn,course.name,mark,reg.hours 
                        FROM reg,student,course 
                        where reg.student_ssn=$student_sssn 
                        and reg.student_ssn=student.ssn  
                        and reg.course_code=course.code 
                        and course.type=reg.course_type and grade is null";

                        $result5 = mysqli_query($data, $sql5);


                        while ($info5 = $result5->fetch_assoc()) {
                        ?>
                            <tr>
                                <div class="add_int">
                                    <td></td>
                                    <td><input style=" text-align: center; margin-left: 20px; border-radius: 9px; background-color: grey; margin-bottom: 9px; margin-top: 8px;" class="input" type="text" name="course_code[]" value="<?php echo "{$info5['code']}"; ?>" readonly /></td>
                                    <td><input style=" text-align: center; margin-left: 20px; border-radius: 9px; background-color: grey; margin-bottom: 9px; margin-top: 8px;" class="input" type="text" name="course_name[]" value="<?php echo "{$info5['name']}"; ?>" readonly /></td>
                                    <td><input style=" text-align: center; margin-left: 20px; border-radius: 9px; background-color: grey; margin-bottom: 9px; margin-top: 8px;" class="input" type="text" name="hours[]" value="<?php echo "{$info5['hours']}"; ?>" readonly /></td>
                                    <td><input multiple style=" text-align: center; border-radius: 9px; background-color: white; margin-bottom: 9px; margin-top: 8px;" class="input" type="number" name="mark[]" placeholder="enter course mark" value="<?php echo "{$info5['mark']}"; ?>"></input>
                                </div>
                            </tr>

                        <?php
                        }
                        ?>

                        <tr>
                            <td></td>
                            <div>
                                <td colspan="3"> <input type="submit" style="margin-left: 320px; margin-bottom: 9px; margin-top: 8px;" class="btn btn-success" name="insert_Courses_Degrees" value="Insert Degrees"></td>
                            </div>
                        </tr>
                    </form>

                </div>
            </table>
        </center>
    </div>
</body>

</html>