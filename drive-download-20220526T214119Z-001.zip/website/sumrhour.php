<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>summer hour update</title>
      <link rel="stylesheet" href="adminhour.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
    <div class="main"> 
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="#">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
                  
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>

      <form method="POST" class="form" >

                  <p> Department name : </p>
                           <input type="radio" id="cs" name="dep" value="1" />
                           <label for="cs">Computer Science</label><br/>
                           <input type="radio" id="ss" name="dep" value="2"/>
                           <label for="ss">stat-cs</label><br/>
                           <input type="radio" id="gs" name="dep" value="3"/>
                           <label for="ms">Math-cs</label><br/>
             <br/>
                  <p >Level : </p>
                           <input type="radio" id="1" name="level" value="1" />
                           <label for="1"> 1 </label><br/>
                           <input type="radio" id="2" name="level" value="2"/>
                           <label for="2"> 2 </label><br/>
                           <input type="radio" id="3" name="level" value="3"/>
                           <label for="3"> 3 </label><br/> 
                           <input type="radio" id="4" name="level" value="4" />
                           <label for="4"> 4 </label><br/>

            <br/>
                  <p> Hours number : </p>
                        <select name="hour" id="hour" >
                           <option value="1">1</option>
                           <option value="2">2</option>
                           <option value="3">3</option>
                           <option value="4">4</option>
                           <option value="5">5</option>
                           <option value="6">6</option>
                           <option value="7">7</option>
                           <option value="8">8</option>
                           <option value="9">9</option>
                           <option value="10">10</option>
                        </select>

            <br/>  
            <button class="btnn" type="submit" name="btnupdate"><a href="#">Save</a></button>              
            <br/>
               
       </form>

    </div>
   </body>
</html>

<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "yos";

  //  $con= mysqli_connect($dbhost,$dbuser,$dbpass,$db);
  $con= mysqli_connect($dbhost,$dbuser,$dbpass,$db);
  if(mysqli_connect_errno())
  {
      echo"failed";
      exit();
  }
if(isset($_POST["btnupdate"]))
{ 

    if((empty($_POST["level"]))||(empty($_POST["dep"]))||(empty($_POST["hour"])))
    {
        echo' <script type="text/javascript">alert(" please enter all data") </script>';
    }
    else
    {
        $level = $_POST["level"]; 
        $dep = $_POST["dep"] ;   
        $hour = $_POST["hour"] ;
        $query="UPDATE prog_summers SET hours='$hour' WHERE program_number= '$dep' and level='$level' ";
        $stat=$con->prepare($query);
        $stat->execute();
        if (mysqli_query($con, $query)) {
            echo' <script type="text/javascript">alert(" Record updated successfully")</script>';
        } else {
            echo' <script type="text/javascript">alert(" Record Not updated successfully")</script>';
        }
    }
}


?>