<?php
session_start();
$con = mysqli_connect("localhost","root","","yos");

if(isset($_POST['save_multicheckbox']))
{
    $courses_list = $_POST['courses_list'];
    if (is_array($courses_list) || is_object($courses_list))
    {
            foreach($courses_list as $courses)
        {
            //echo $courses."<br>";
            $query = "UPDATE course SET activated = true WHERE code IN ('$courses')";
            $query_run = mysqli_query($con, $query);

            
        }
    }

    if($query_run)
    {
      
        header("Location: adminactcour.php");
    }
    else{
       
        header("Location: adminactcour.php");
    }
    
}
?>