<?php
session_start();
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Activate Courses</title>
      <link rel="stylesheet" href="adminhour.css">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
    <div class="main"> 
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="#">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
                  
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>

     
    <?php
        if(isset($GET['btnGetCourses'])){

            $depart = $_GET['depart'];
            $lvl = $_GET['lvl'];
            $sem = $_GET['sem'];

        }
    ?>
        <form method="GET"action="check.php" class="form">
        <p> Department name : </p>
            <input type="radio" id="cs" name="depart" value="1">
            <label for="cs">CS</label>
            <br>
            <input type="radio" id="ms" name="depart" value="3">
            <label for="ms">MATH-CS</label>
            <br>
            <input type="radio" id="ss" name="depart" value="2">
            <label for="ss">STAT-CS</label>
            <br>
    
    
            <p >Level : </p>
            <input type="radio" id="lvl-2" name="lvl" value="2">
            <label for="lvl-2"> 2 </label>
            <br>
            <input type="radio" id="lvl-3" name="lvl" value="3">
            <label for="lvl-3"> 3 </label>
            <br>
            <input type="radio" id="lvl-4" name="lvl" value="4">
            <label for="lvl-4"> 4 </label>
            <br>


            <p >Semseter : </p>
            <input type="radio" id="sem-1" name="sem" value="1">
            <label for="sem-1"> 1 </label>
            <br>
            <input type="radio" id="sem-2" name="sem" value="2">
            <label for="sem-2"> 2 </label>
            <br><br><br>

            <button  class="btnn" type="submit" value="Get Courses" name="btnGetCourses"><a href="#"> Get Courses </a></button> 
           
        </form >
 </body>   
 </html>


    

    




