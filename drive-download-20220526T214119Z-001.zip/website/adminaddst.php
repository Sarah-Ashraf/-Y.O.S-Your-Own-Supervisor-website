<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
      <meta charset="utf-8">
      <title>Add Student</title>
      <link rel="stylesheet" href="adminaddst.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>

<body>
    <div class="main"> 
    <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="#">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
                 
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>

        <center>
            <h2>Add New Student</h2>
            <br>
            <table class="div_deg" >
                    <form method="POST" class="form_deg" >
                        <tr>
                            <div>
                                <td> <p>Academic Number :</p></td>
                                <td><input placeholder="Enter Academic Number" class="input" type="number" name="acadamiccode"></td>
                            </div>  
                            <div class="a">
                                <td><label> Username :</label></td>
                                <td><input placeholder="Enter UserName" class="input" type="text" name="stusername"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td> <label> Name :</label></td>
                                <td><input placeholder="Enter Name" class="input" type="text" name="stname"></td>
                            </div>

                            <div>
                                <td><label> SSN :</label></td>
                                <td><input placeholder="Enter SSN" class="input"  name="ssn"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label> Password :</label></td>
                                <td><input placeholder="Enter Password" class="input" type="text" name="stpassword"></td>
                            </div>

                            <div>
                                <td><label> Phone :</label></td>
                                <td><input placeholder="Enter Phone" class="input" type="number" name="phone"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label> Nationality :</label></td>
                                <td><input placeholder="Enter Nationality" class="input" type="text" name="nationality"></td>
                            </div>

                            <div>
                                <td><label >Level :</label></td>
                                <td><input placeholder="Enter Level" class="input" type="number" name="level"></td>
                            </div>
                        </tr>

                        <tr>
                          
                            <div>
                                <td><label> Program Number : </label></td>
                                <td>     
                                      <select name="program_number">
                                               <option value="1">CS</option>
                                               <option value="2">STAT_CS</option>
                                               <option value="3">MATH_CS</option>
                                       </select>
                            </td>
                            </div>
                        </tr>
                        <tr>
                            <div>
                                <td><label class="label">Supervisor SSN</label></td>
                                <td><input placeholder="Enter supervisor snn" class="input" type="number" name="supervisor_supssn"></td>
                            </div>
                        </tr>
                        <tr>
                            <td colspan="3"> <input type="submit"  class="btnn" name="insert" value="Add Student"></td>
                        </tr>
                    </form>
            </table>
        </center>
    </div>
</body>
</html>


<?php
//session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

if (isset($_POST['insert'])) 
{
    $student_ssn = $_POST['ssn'];
    $student_phone = $_POST['phone'];
    $student_name = $_POST['stname'];
    $student_username = $_POST['stusername'];
    $student_pass = $_POST['stpassword'];
    $student_nationality = $_POST['nationality'];
    $student_level = $_POST['level'];
    $student_academic_number = $_POST['acadamiccode'];
    $student_program_number = $_POST['program_number'];
    $student_super_ssn = $_POST['supervisor_supssn'];

    $sql2 = "INSERT INTO student(ssn,phone,stname,stusername,stpassword,nationality,level,acadamiccode,program_number,supervisor_supssn)
    VALUES('$student_ssn','$student_phone','$student_name','$student_username','$student_pass','$student_nationality'
    ,'$student_level','$student_academic_number','$student_program_number','$student_super_ssn')";
    $result = mysqli_query($data, $sql2);

    if( (empty($_POST['stusername']))|| (empty($_POST['stname'])) || (empty($_POST['ssn'])) || (empty($_POST['stpassword'])) || (empty($_POST['phone'])) || (empty($_POST['nationality'])) || (empty($_POST['level'])) || (empty($_POST['acadamiccode'])) || (empty($_POST['program_number'])) || (empty($_POST['supervisor_supssn'])) ) 
    {
        echo ' <script type="text/javascript">alert(" enter all data")</script>';
    }
    else
    {
        if ($result) {
            echo ' <script type="text/javascript">alert(" Record inserted successfully")</script>';
        } else {
            echo '<script type="text/javascript">alert(" Record inserted failed")</script>';
        }
    }
}

?>


