<!DOCTYPE html>
<html lang="en">
<head>
    <title>ABOUT</title>
   <!-- <link rel="stylesheet" href="styleabout.css">-->
<style>

*{
    margin: 0;
    padding: 0;
}
body{
   
    width: 100%;
    background-image: url("6.jpg");
    background-position: center;
    background-size: cover;
    height: 100vh;
}

.form{
  margin-top: 20px;
  width: 100px;
  height: 150px;
  margin-left: 370px;
  background: linear-gradient(to top, rgba(0,0,0,0.8)50%,rgba(0,0,0,0.8)50%);
 
  border-radius: 10px;
  padding: 25px;
 
}


.navbar{
    width: 1200px;
    height: 75px;
    margin: auto;
}

.icon{
    width: 200px;
    float: left;
    height: 70px;
}

.logo{
    color: #ff7200;
    font-size: 35px;
    font-family: Arial;
    padding-left: 20px;
    float: left;
    padding-top: 10px;
    margin-top: 5px
}

.menu{
    width: 400px;
    float: left;
    height: 70px;
}

ul{
    float: left;
    display: flex;
    justify-content: center;
    align-items: center;
}

ul li{
    list-style: none;
    margin-left: 62px;
    margin-top: 27px;
    font-size: 14px;
}

ul li a{
    text-decoration: none;
    color: #fff;
    font-family: Arial;
    font-weight: bold;
    transition: 0.4s ease-in-out;
}

ul li a:hover{
    color: #ff7200;
}

.content{
    width: 1200px;
    height: auto;
    margin: auto;
    color: #fff;
    position: relative;
}

.content p{
    padding-left: 10px;
    padding-bottom: 5px;
    font-family: Arial;
    letter-spacing: 1.2px;
    line-height: 30px;
    font-size: 16px;
    margin-top:15px;
    font-weight: bold;
}

.content h1{
    font-family: 'Times New Roman';
    font-size: 50px;
    padding-left: 20px;
    margin-top: 10px;
    letter-spacing: 2px;
}






    </style>

</head>
<body>
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Y.O.S</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="#">ABOUT US</a></li>
                    
                    <li><a href="logout.php" style="color:#ff7200">LOGOUT</a></li>
                </ul>
            </div>
        </div> 
    </div>


    <div class="content">

            <p class="par"> 
                    YOS saves time and efforts in facilitating for both the supervisor and the student, whether in the operations related to university courses or in guiding him during the educational process.   Approval to register materials provided that all conditions are met instead of supervisor.
                     <br><br><span style="color:#ff7200; font-size: 25px;">YOS for students</span><br>
                    •	Reduce effort, find support for your academic registration.<br>
                    •	Find information about registration and rules.<br>
                    •	registration, instead of it being paper and taking time, now it will be electronic and in an easy and simple way he can register the materials.<br>
                    •	Calculate GPA for each student after adding his courses degrees. <br>
                    •	Connect you with your supervisor easily through his email.<br><br>
                   <span style="color:#ff7200; font-size: 25px;"> YOS for Supervisors</span><br>
                    •	reduce the burden on him, and among these tasks.<br>
                    •	Allow Supervisor to see his student under under his guidance.<br><br>
                    <span style="color:#ff7200; font-size: 25px;"> YOS for Admin</span><br>
                    •	Creating accounts or add or delete or update for students and supervisors.<br>
                    •	Insert courses degrees for each student.<br>
                    •	Allow admin to assign/reassign students to a specific supervisor.  <br>
                    •	Activate courses in normal semesters and summer semester.<br><br>
                
            </p>
                    

       
              
                </div>                     
                
</body>
</html>