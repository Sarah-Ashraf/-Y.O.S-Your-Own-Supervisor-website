<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);
$supervisor_ssn = $_GET['supervisor_assn'];

$sql = "SELECT * FROM supervisor WHERE supssn=$supervisor_ssn";
$result = mysqli_query($data, $sql);
$info = $result->fetch_assoc();


if (isset($_POST['uppdate_supervisor'])) {
    $sup_email=$_POST['email'];
    $sup_pass=$_POST['password'];
    $supssn=$_POST['supssn'];
    $sql2 = " UPDATE supervisor SET supemail='$sup_email' , suppassword='$sup_pass' where supssn=' $supssn' ";
    $result2 = mysqli_query($data, $sql2);
    
    if ( (empty($sup_email)) || (empty($sup_pass)) ) 
    {
        echo ' <script type="text/javascript">alert(" enter updated data ,please")</script>';
    }
    else{
        if ($result2) {
            echo' <script type="text/javascript">alert(" updated successfully") </script>';
            }
        else {
            echo' <script type="text/javascript">alert(" updated failed") </script>';  
            }
    }
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
      <meta charset="utf-8">
      <title>update supervisor</title>
      <link rel="stylesheet" href="adminaddsup.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/><title> Y.O.S </title>

    <style type="text/css">

    </style>
</head>
<body>
    <div class="main"> 
    <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>
        <center>
            <h2>Update Supervisor</h2>
            <table class="div_deg">
            <form action="#" method="POST">

                <input type="text" name="supssn" value="<?php echo "{$info['supssn']}" ?>" hidden />
                <tr>
                    <div class="add_int">
                    <td> <label class="label_text">Name :</label></td>
                    <td> <input class="input" type="text" name="supname" value="<?php echo "{$info['supname']}"; ?>" readonly /></td>
                    </div>
                </tr>

                <tr>
                    <div class="add_int">
                    <td><label class="label_text">National ID :</label></td>
                    <td><input class="input" type="number" name="supssn" value="<?php echo "{$info['supssn']}"; ?>" readonly /></td>
                    </div>
                </tr>
                <tr>
                    <div class="add_int">
                    <td> <label class="label_text">Username :</label></td>
                    <td> <input placeholder="Enter UserName" class="input" type="text" name="supusername" value="<?php echo "{$info['supusername']}"; ?>" readonly /></td>
                    </div>
                </tr>

                <tr>
                    <div class="add_int">
                    <td><label class="label_text">Password :</label></td>
                    <td><input class="input" type="text" name="password" placeholder="Enter new password" /></td>
                    </div>
                </tr>

                <tr>
                    <div class="add_int">
                    <td> <label class="label_text">Email :</label></td>
                    <td><input class="input" type="email" name="email" value="<?php echo "{$info['supemail']}"; ?>"/></td>
                    </div>
                </tr>
                <tr>
                    <div class="add_int">
                    <td colspan="2"> <button class="btnn" id="submit" type="submit" name="uppdate_supervisor">Update</button></td>
                    </div>
                </tr>

            </form>
</table>
    </center>
</body>

</html>
