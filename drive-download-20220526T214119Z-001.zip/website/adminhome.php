<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Admin</title>
      <link rel="stylesheet" href="adminhour.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
    <div class="main"> 
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>
    </div>
   </body>
</html>