<!DOCTYPE html>
<html lang="en">
<head>
    <title>SERVICE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Y.O.S</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="#">SERVICE</a></li>
                   
                    <li><a href="logout.php" style="color:#ff7200">LOGOUT</a></li>
                </ul>
            </div>


        </div> 

    </div>

</body>
</html>