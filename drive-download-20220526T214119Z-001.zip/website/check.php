<?php
 session_start();
 ?>
 <!DOCTYPE html>
<html lang="en">    
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="adminhour.css">
        <title>Activate Courses</title>
    </head>
        <body>

                        <center><h2>Activate Courses</h2></center>


            <form class="form" action="code.php" method="POST">
     <?php
            $con = mysqli_connect("localhost","root","","yos");

            global $depart;
            global $sem;
            global $lvl;
            if(isset($_GET['btnGetCourses'])){

                $depart = $_GET["depart"];
                $lvl = $_GET["lvl"];
                $sem = $_GET["sem"];
            }
            $courses_query = "SELECT code FROM course, include WHERE course_code = code and course_type = type and include.program_number=$depart and level =$lvl and semester=$sem and type like '%elective%'";
            $query_run = mysqli_query($con,$courses_query);


            $query2="UPDATE course , include SET activated = true WHERE course_code = code and course_type = type and (type='mandatory' or type='asu') and include.program_number=$depart  and semester=$sem ";
            $query2_run = mysqli_query($con,$query2);
            if(mysqli_num_rows($query_run) > 0)
            {
                foreach($query_run as $courses)
                {
                    ?>
                    <input type="checkbox" name ="courses_list[]" value="<?= $courses['code']; ?>" /> 
                    <?= $courses['code']; ?>
                     <br/>
                    <?php
                }
            }
            else{
                echo " NO Elective courses in Level.'$lvl'. semester .'$sem'., Mandatory courses activited ";
            }
     ?>
            <button name="save_multicheckbox" class="btnn">Save</button>
                            
        </form>


 
</body>
</html>