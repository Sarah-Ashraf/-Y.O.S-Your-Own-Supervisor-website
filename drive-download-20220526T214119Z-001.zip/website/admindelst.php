<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

if ($_GET['ssn']) {
    $student_ssn = $_GET['ssn'];
    $sql2 = "DELETE FROM student WHERE ssn='$student_ssn'";
    $result=mysqli_query($data,$sql2);
    if($result){
        $_SESSION['message']=' <script type="text/javascript">alert("Student is Deleted Successfully.")</script>';
        header("location:/website/adminviewst.php");
    }
}
?>
