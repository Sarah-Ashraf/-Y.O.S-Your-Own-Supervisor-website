
<?php
    error_reporting(0);
    session_start();
    $host = "localhost";
    $user = "root";
    $password = "";
    $db = "yos";

    $data = mysqli_connect($host, $user, $password, $db);
    ?>

<!DOCTYPE html>
<html lang="en">
<head>

      <meta charset="utf-8">
      <title>Add Student</title>
      <link rel="stylesheet" href="adminviewst.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<div class="main">
        <nav>
            <label class="logo">Y.O.S</label>
            <ul>
            <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

                <li>
                <a href="#">Summer
                <i class="fas fa-caret-down"></i>
                </a>
                <ul>
                    <li><a href="sumrhour.php">Available Hour</a></li>
                    <li><a href="sumrcour.php">Course activation</a></li>
                    <li><a href="sumview.php">View Courses</a></li>
                </ul>
                </li>

                <li>
                <a href="#">Student
                <i class="fas fa-caret-down"></i>
                </a>
                    <ul>
                        <li><a href="adminaddst.php">Add Students</a></li>
                        <li><a href="#">View students</a></li>
                    
                    </ul>
                </li>

                <li>
                    <a href="#">Supervisor
                    <i class="fas fa-caret-down"></i>
                    </a>
                    <ul>
                    <li><a href="adminaddsup.php">Add Supervisor</a></li>
                    <li><a href="adminviewsup.php">View Supervisor</a></li>   
                    </ul>
                </li>

                <li><a class="active" href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>

        <br>
         
                   

<?php
    $sql = " SELECT * FROM student ";
    $result = mysqli_query($data, $sql);
?>
        <center>
            <?php
            if ($_SESSION['message']) {
                echo $_SESSION['message'];
            }

            unset($_SESSION['message']);
            ?>
             <br>
            <table>
                <tr>
                    <th class="table_th">Acd.No.</th>
                    <th class="table_th">Name</th>
                    <th class="table_th">Username</th>
                    <th class="table_th">SSN</th>
                    <th class="table_th">Phone</th>
                    <th class="table_th" style="padding: 5px;">Level</th>
                    <th class="table_th" style="padding: 5px;" >Program</th>
                    <!--<th class="table_th">Course Code</th>-->
                    <th class="table_th" style="padding: 5px;" >Supervisor SSN</th>
                    <th class="table_th" style="padding: 5px;">GPA</th>
                    <th class="table_th"> Insert Degrees</th>
                    <th class="table_th">Delete</th>
                    <th class="table_th">Update</th>
                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td" >
                            <?php echo "{$info['acadamiccode']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['stname']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['stusername']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['ssn']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['phone']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['level']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php
                            if ("{$info['program_number']}" == '1') {
                                echo "Computer Science";
                            } else if ("{$info['program_number']}" == '2') {
                                echo "Stat_CS";
                            } else if ("{$info['program_number']}" == '3') {
                                echo "Math_CS";
                            }
                            ?>
                        </td>

                        <!--<td class="table_td">
                            <?php //echo "{$info['course_code']}"; 
                            ?>
                        </td>-->

                        <td class="table_td">
                            <?php echo "{$info['supervisor_supssn']}"; // i can't show super name
                            ?>
                        </td>

                        <td class="table_td">
                            <?php echo "{$info['gpa']}"; //echo "<a class='btn btn-success' href='insert_GPA.php?student_ssn={$info['ssn']}'> Add GPA </a>"; 
                            ?>
                        </td>

                        <td class="table_td">
                            <?php echo "<button class='btnn'><a href='admininsrst.php?ssn={$info['ssn']}'>Insert Mark </a></button>"; ?>
                        </td>

                        <td class="table_td">
                            <?php echo "<button class='btnn'><a onClick=\"javascript:return confirm('Are You Sure To Delete This');\" href='admindelst.php?ssn={$info['ssn']}'> Delete </a></button>"; ?>
                        </td>

                        <td class="table_td" >
                            <?php echo "<button class='btnn'><a  href='adminupst.php?ssn={$info['ssn']}'> Update </a></button>"; ?>
                        </td>
                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>