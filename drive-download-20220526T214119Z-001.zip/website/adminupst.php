<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

$student_sssn = $_GET['ssn'];

$sql = "SELECT * FROM student WHERE ssn='$student_sssn' ";

$result = mysqli_query($data, $sql);

$info = $result->fetch_assoc();

if (isset($_POST['update'])) {
   
    $student_username = $_POST['stusername'];
    $student_name = $_POST['stname'];
    $student_ssn = $_POST['ssn'];
    $student_pass = $_POST['stpassword'];
    $student_phone = $_POST['phone'];
    $student_nationality = $_POST['nationality'];
    $student_level = $_POST['level'];
    
    $student_academic_number = $_POST['acadamiccode'];
    $student_program_number = $_POST['program_number'];
    $student_super_ssn = $_POST['supervisor_supssn'];

    //$sql2 = "UPDATE student(ssn,phone,stname,stusername,stpassword,nationality,level,acadamiccode,program_number,supervisor_supssn)VALUES('$student_ssn','$student_phone','$student_name','$student_username','$student_pass','$student_nationality','$student_level','$student_academic_number','$student_program_number','$student_super_ssn')";
    $sql2 =  "UPDATE student SET stusername='$student_username',stname='$student_name',
    ssn='$student_ssn',stpassword='$student_pass',phone='$student_phone',
    nationality='$student_nationality',level='$student_level',
    acadamiccode='$student_academic_number',program_number='$student_program_number'
    ,supervisor_supssn='$student_super_ssn' WHERE ssn='$student_ssn' ";
   
   $result2 = mysqli_query($data, $sql2);

   if( (empty($_POST['stusername']))|| (empty($_POST['stname'])) || (empty($_POST['ssn'])) || (empty($_POST['stpassword'])) || (empty($_POST['phone'])) || (empty($_POST['nationality'])) || (empty($_POST['level'])) || (empty($_POST['acadamiccode'])) || (empty($_POST['program_number'])) || (empty($_POST['supervisor_supssn'])) ) 
   {
       echo ' <script type="text/javascript">alert(" enter all data")</script>';
   }
   else
   {
       if ($result2) {
           echo ' <script type="text/javascript">alert(" Record inserted successfully")</script>';
       } else {
           echo '<script type="text/javascript">alert(" Record inserted failed")</script>';
       }
   }

}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
      <meta charset="utf-8">
      <title>Add Student</title>
      <link rel="stylesheet" href="adminaddst.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>

<body>
<div class="main"> 
    <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
               <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
               </ul>
            </li>

            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>
        <center>
            <h2>Update Student's Data</h2>
            <br>
            <table class="div_deg">
                <div>
                    <form action="#" method="POST">
                        <tr>
                            <div>
                                <td><label class="label"> Academic Number :</label></td>
                                <td><input class="input" type="number" name="acadamiccode" value="<?php echo "{$info['acadamiccode']}"; ?>" readonly></td>
                            </div>

                            <div>
                                <td><label> Username :</label></td>
                                <td><input class="input" type="text" name="stusername" value="<?php echo "{$info['stusername']}"; ?>"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label> Name :</label></td>
                                <td><input class="input" type="text" name="stname" value="<?php echo "{$info['stname']}"; ?>" ></td>
                            </div>

                            <div>
                                <td><label> SSN :</label></td>
                                <td><input class="input" type="number" name="ssn" value="<?php echo "{$info['ssn']}"; ?>" readonly></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label> Password :</label></td>
                                <td><input class="input" type="text" name="stpassword" placeholder="Enter new password"></td>
                            </div>

                            <div>
                                <td><label> Phone :</label></td>
                                <td><input class="input" type="number" name="phone" value="<?php echo "{$info['phone']}"; ?>"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label> Nationality :</label></td>
                                <td><input class="input" type="text" name="nationality" value="<?php echo "{$info['nationality']}"; ?>" readonly></td>
                            </div>

                            <div>
                                <td><label> Level :</label></td>
                                <td><input class="input" type="number" name="level" value="<?php echo "{$info['level']}"; ?>" readonly></td>
                            </div>
                        </tr>

                        <tr>
                           
                            <div>
                                <td><label class="label"> Program Number :</label></td>
                                <td><input class="input" type="number" name="program_number" value="<?php echo "{$info['program_number']}"; ?>" readonly></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td><label class="label"> Supervisor SSN :</label></td>
                                <td><input class="input" type="number" name="supervisor_supssn" value="<?php echo "{$info['supervisor_supssn']}"; ?>"></td>
                            </div>
                        </tr>

                        <tr>
                            <div>
                                <td colspan="4"><input type="submit"  class="btnn" name="update" value="Update Data"></td>
                            </div>
                        </tr>
                    </form>
                </div>
            </table>
        </center>
</body>

</html>

