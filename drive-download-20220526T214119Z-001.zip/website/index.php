<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Y.O.S</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="#">HOME</a></li>
                    <li><a href="about.php">ABOUT US</a></li>
                   
                    <li><a href="logout.php" style="color:#ff7200">LOGOUT</a></li>
                </ul>
            </div>


        </div> 

        <div class="content">
            <h1> Your <span> Own </span>Supervisor</h1>
            <p class="par"> 
              <br> It provides you with a simple and smooth use in following up and modifying your information 
                <br> Enables you to easily communicate with your academic advisor.</p>
                    <br><br>

                <div class="form" >
                    <form method="POST">
                        <h2>Login Here</h2>
                        <input type="text" name="username" placeholder="Enter Username Here">
                        <input type="password" name="password" placeholder="Enter Password Here">

                        
                    
                        <p> User Type :</p>
                        <select name="usertype" >
                            <option value='1'>Student</option>
                            <option value='2'>Supervisor</option>
                            <option value='3'>Admin</option>
                        </select>

                
                        <button class="btnn" type="submit"name="submit"><a href="#">Login</a></button>
                 </form>
                </div>         
                
               
        </div>
    </div>

</body>
</html>


<?php
error_reporting(0);
session_start();

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "yos";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $db);
if (mysqli_connect_errno()) {
    echo "failed";
    exit();
}

if (isset($_POST["submit"])) {
    $name = $_POST['username'];
    $pass = $_POST['password'];
    $type = $_POST['usertype'];

    if ($type == '1') {
        $sql = "SELECT * FROM student where stusername='$name' and stpassword='$pass' ";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($result);
        if (!empty($name) && !empty($pass)) {
            if (!empty($row))
             {
                $info = $name;
                header("location:/Project_IN_PHP_AND_JAVASCRIPT/student_real/studenthome.php?us=$info");
            } else {
                echo ' <script type="text/javascript">alert("Unavailable Account !")</script>';
            }
        } else {
            echo ' <script type="text/javascript">alert("Please Enter Username and Password !")</script>';
        }
    }
    if ($type == '2') {
        $sql = "SELECT * FROM supervisor where supusername='$name' and suppassword='$pass' ";
        $result = mysqli_query($con, $sql);
        $row1 = mysqli_fetch_array($result);
        if (!empty($name) && !empty($pass)) {
            if (!empty($row1)) {
                $info = $name;
                header("location:/Project_IN_PHP_AND_JAVASCRIPT/supervisor_real/superhome.php?us=$info");
            } else {
                echo ' <script type="text/javascript">alert("Unavailable Account !")</script>';
            }
        } else {
            echo ' <script type="text/javascript">alert("Please Enter Username and Password !")</script>';
        }
    }
    if ($type == '3') {
        $admin = 'admin';
        $adminpass = '13579';
        $x = '3';
        if (!empty($name) && !empty($pass)) 
        {

            if (($name == $admin) && ($pass == $adminpass) && ($x == $type))
            {
                header("location:/website/adminhome.php");
            }
            else 
            {
                echo ' <script type="text/javascript">alert("Unavailable Account !")</script>';
            }
        }
        else 
        {
            echo ' <script type="text/javascript">alert("Please Enter Username and Password !")</script>';
        }
    }
}
?>