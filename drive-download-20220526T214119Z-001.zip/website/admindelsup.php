<?php


session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";

$data = mysqli_connect($host, $user, $password, $db);

if ($_GET['supervisor_assn']) {
    $super_ssn = $_GET['supervisor_assn'];
    $sql = "DELETE FROM supervisor WHERE supssn='$super_ssn'";
    $result = mysqli_query($data, $sql);
    if($result){
    $_SESSION['message']=' <script type="text/javascript">alert("Supervisor is Deleted Successfully.")</script>';
       header("location:/website/adminviewsup.php");
    }
 
}
?>