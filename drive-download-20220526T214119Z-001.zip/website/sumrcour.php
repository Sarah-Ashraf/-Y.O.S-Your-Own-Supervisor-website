<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>active summer course</title>
      <link rel="stylesheet" href="admincour.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
    <div class="main"> 
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="#">Course activation</a></li>
                  <li><a href="sumview.php">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
               </ul>
            </li>
            
            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>

      <form method="POST"  class="form">
         <div class="wrapper">
            <div class="search-input">
               <a href="" target="_blank" hidden></a>
               <input type="text" placeholder="Type course name.." name="code">
               <div class="autocom-box">
                  <!-- here list are inserted from javascript -->
               </div>
               <div class="icon"><i class="fas fa-search"></i></div>
            </div>
         </div>
         <script src="/website/suggestions.js"></script>
         <script src="/website/script.js"></script>

         <input class="btnn" type="submit" name="btnupdate" value="Open">
         <input class="btnn" type="submit" name="closeupdate" value="Close all courses">
      </form>

    </div>
   </body>
</html>

<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "yos";

//  $con= mysqli_connect($dbhost,$dbuser,$dbpass,$db);
$con= mysqli_connect($dbhost,$dbuser,$dbpass,$db);
if(mysqli_connect_errno())
{
  echo"failed";
  exit();
}

if (isset($_POST["btnupdate"])) 
{
  
  $codename = $_POST["code"];
  if (empty($codename)) 
  {
    echo '<script type="text/javascript"> alert(" please enter course name") </script>';
  } 
  else 
  {
    $q = "SELECT code from course WHERE code='$codename'";
    $result1 = mysqli_query($con, $q);
    if ($result1 == "") 
    {
      echo '<script type="text/javascript"> alert("ERROR! course name") </script>';
    } 
    else 
    {
      $active1 = TRUE;
      $query1 = " UPDATE course SET activated='$active1' WHERE code='$codename' ";
      $result2 = mysqli_query($con, $query1);
    }
  }
}

if (isset($_POST["closeupdate"])) 
{
  $active2 = FALSE;
  $query2 = " UPDATE course SET activated='$active2' ";
  $result3 = mysqli_query($con, $query2);
  if (mysqli_query($con, $query2)) 
  {
    echo '<script type="text/javascript">alert("ALL COURSES CLOSED")</script>';
  }
}
?>