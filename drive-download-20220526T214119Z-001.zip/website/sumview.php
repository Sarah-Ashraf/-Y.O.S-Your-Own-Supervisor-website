<?php

error_reporting(0);
session_start();
/*if (!isset($_SESSION['username'])) {
    header("location:login.php");
} else if ($_SESSION['usertype'] == "student") {
    header("location:login.php");
}*/
$host = "localhost";
$user = "root";
$password = "";
$db = "yos";
global $codename;
$data = mysqli_connect($host, $user, $password, $db);
$active1 = TRUE;
$sql = "SELECT * FROM course  WHERE  activated='$active1' ";

$result = mysqli_query($data, $sql);

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>View Courses</title>
      <link rel="stylesheet" href="adminviewst.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
   <body>
    <div class="main"> 
      <nav>
         <label class="logo">Y.O.S</label>
         <ul>
         <li><a class="active" href="adminactcour.php">Courses Activation</a></li>

            <li>
               <a href="#">Summer
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="sumrhour.php">Available Hour</a></li>
                  <li><a href="sumrcour.php">Course activation</a></li>
                  <li><a href="#">View Courses</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Student
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddst.php">Add Students</a></li>
                  <li><a href="adminviewst.php">View students</a></li>
               </ul>
            </li>

            <li>
               <a href="#">Supervisor
               <i class="fas fa-caret-down"></i>
               </a>
               <ul>
                  <li><a href="adminaddsup.php">Add Supervisor</a></li>
                  <li><a href="adminviewsup.php">View Supervisor</a></li>
               </ul>
            </li>
            
            <li><a class="active" href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>

    <div class="content">
        <center>
            <?php
            if ($_SESSION['message']) {
                echo $_SESSION['message'];
            }

            unset($_SESSION['message']);
            ?>
            <br>
            <table>
                <tr>
                    <th class="table_th">Course Code</th>
                    <th class="table_th">Course Name</th>
                    <th class="table_th">Course Hours</th>
                    <th class="table_th">Course Type</th>
                    <th class="table_th">Activativation</th>




                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {

                ?>

                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['code']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['name']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['credithour']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['type']}"; ?>
                        </td>
                        <td class="table_td">
                            <?php

                            if ("{$info['activated']}" == '0') {
                                echo "No";
                            } else if ("{$info['activated']}" == '1') {
                                echo "Yes";
                            }
                            ?>

                        </td>

                    </tr>
                <?php
                }
                ?>

            </table>
        </center>
    </div>
</body>

</html>